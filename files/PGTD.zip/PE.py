from sys import stdout
import scipy.io
import numpy as np
import sklearn.utils
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1.inset_locator import mark_inset
from mpl_toolkits.axes_grid1.inset_locator import zoomed_inset_axes
import datetime
import time
import glob


# For parsing result files
def chooseFile(rank=0,suffix='_Energy.npy',fmt='%Y-%m-%d-%H-%M-%S'):
    dates = [i.strip(suffix) for i in glob.glob('*'+suffix)]
    datetimes = [time.strptime(date,fmt) for date in dates]
    ordered = sorted(datetimes,reverse=True)
    selected = datetime.datetime(*ordered[rank][:6])
    return selected.strftime(fmt+'_{fname}').format(fname=suffix.strip('_'))


# For time stamps
def timeStamped(fname, fmt='%Y-%m-%d-%H-%M-%S_{fname}'):
    return datetime.datetime.now().strftime(fmt).format(fname=fname)


# PE helper functions
def td_error(theta,r,dphi):
    return r - np.dot(dphi,theta)


def delta_phi(phi,phi_nxt,gam):
    return phi - gam*phi_nxt


# PE methods
def td(y,theta,alpha,rho,td_err,phi,dphi,r=None,gam=None):
    theta_new = theta + alpha*rho*td_err*phi
    return (y, theta_new)


def etd0(F,theta,alpha,rho,td_err,phi,dphi,r=None,gam=None):
    # this is a hack: y is replaced by np.array([F_t])
    if len(F) > 1:
        F = 1
    else:
        F = F[0]
    theta_new = theta + alpha*F*rho*td_err*phi
    F_new = gam*rho*F + 1
    # pack F up in a numpy array again
    return (np.array([F_new]),theta_new)


def gtd(y,theta,alpha,rho,td_err,phi,dphi,r=None,gam=None):
    y_new = y + alpha*(rho*td_err*phi-y)
    theta_new = theta + alpha*rho*dphi*np.dot(y,phi)
    return (y_new,theta_new)


def gtd2(y,theta,alpha,rho,td_err,phi,dphi,r=None,gam=None):
    y_new = y + alpha*(rho*td_err-np.dot(phi,y))*phi
    theta_new = theta + alpha*rho*dphi*np.dot(y,phi)
    return (y_new,theta_new)


def gtdmp(y,theta,alpha,rho,td_err,phi,dphi,r,gam=None):
    y_m = y + alpha*(rho*td_err*phi-y)
    theta_m = theta + alpha*rho*dphi*np.dot(y,phi)

    td_err_m = td_error(theta_m,r,dphi)

    y_new = y + alpha*(rho*td_err_m*phi-y_m)
    theta_new = theta + alpha*rho*dphi*np.dot(y_m,phi)
    return (y_new,theta_new)


def gtd2mp(y,theta,alpha,rho,td_err,phi,dphi,r,gam=None):
    y_m = y + alpha*(rho*td_err-np.dot(phi,y))*phi
    theta_m = theta + alpha*rho*dphi*np.dot(y,phi)

    td_err_m = td_error(theta_m,r,dphi)

    y_new = y + alpha*(rho*td_err_m-np.dot(phi,y_m))*phi
    theta_new = theta + alpha*rho*dphi*np.dot(y_m,phi)
    return (y_new,theta_new)


def methStrMap():
    return {td:'TD',etd0:'ETD(0)',gtd:'GTD',gtd2:'GTD2',gtdmp:'GTD-MP',
            gtd2mp:'GTD2-MP'}


# Bellman errors - could use a random subset of samples for projection / errors
def train_test_split(testsize,phi,phi_nxt,rand=False):
    testsize = min(testsize,phi.shape[0])
    if rand:
        sklearn.utils.shuffle(phi,phi_nxt)
    test = (phi[:testsize],phi_nxt[:testsize])
    train = (phi[testsize:],phi_nxt[testsize:])
    return train, test


def get_subset(subsetsize,phi,phi_nxt,T):
    if subsetsize == 0:
        if T < phi.shape[0] - 1:
            return phi[:T], phi_nxt[:T]
        else:
            return phi, phi_nxt
    else:
        subset = np.random.choice(phi.shape[0], subsetsize, replace=False)
        return phi[subset], phi_nxt[subset]


def Projection(phi):
    inv_cov = np.linalg.pinv(np.dot(phi.T,phi))
    return phi.dot(inv_cov).dot(phi.T)


def MSBE(theta,phi,phi_nxt,P=None):
    V = np.dot(phi,theta)
    TV = np.dot(phi_nxt,theta)
    return np.linalg.norm(TV-V)


def MSPBE(theta,phi,phi_nxt,P):
    V = np.dot(phi,theta)
    TV = np.dot(phi_nxt,theta)
    Proj_TV = np.dot(P,TV)
    return np.linalg.norm(Proj_TV-V)


# Main loop for updating weights and tracking bellman errors
def learnWeights(y0,theta0,methods,errs,r,phi,phi_nxt,alpha,T,gam,rho,
                 testsize=0,randtest=False):
    # Initalize y and theta weight lists
    ys = [[y0] for m in xrange(len(methods))]
    thetas = [[theta0] for m in xrange(len(methods))]

    # Generate train and test sets
    train, test = train_test_split(testsize,phi,phi_nxt,rand=randtest)
    phi_train, phi_nxt_train = train
    phi_test, phi_nxt_test = test

    # Precompute projection if necessary
    if MSPBE in errs:
        P = Projection(phi_test)
    else:
        P = None

    # Initialize error lists
    error0 = [err(theta0,phi_test,phi_nxt_test,P) for err in errs]
    errors = [[error0] for m in xrange(len(methods))]

    # Learn value function
    completed = ''
    for t in xrange(T):
        stdout.write('\b'*len(completed)+'%d/%d' % (t+1,T))
        stdout.flush()
        completed = '{0}/{1}'.format(t+1,T)

        # Draw random training sample from training set
        s = np.random.randint(phi_train.shape[0])

        # Update y and theta for each algorithm
        dphi = delta_phi(phi_train[s],phi_nxt_train[s],gam)
        for m, method in enumerate(methods):
            # Retrieve y and theta weights from previous step
            y = ys[m][-1].copy()
            theta = thetas[m][-1].copy()

            # Compute temporal difference error
            td_err = td_error(theta,r[s],dphi)

            # Update y and theta weights
            y_new, theta_new = method(y,theta,alpha,rho,td_err,phi_train[s],
                                      dphi,r=r[s],gam=gam)

            # Record y and theta weights
            ys[m].append(y_new)
            thetas[m].append(theta_new)

            # Record errors
            error_new = [err(theta_new,phi_test,phi_nxt_test,P) for err in errs]
            errors[m].append(error_new)
    stdout.write('\n')

    return ys, thetas, errors


# Plotting routines
def plotErrors(errors,methods,errs,T=None):
    errors = np.asarray(errors)  # indexed by (methods,time,err)
    if T is not None:
        errors = errors[:,:min(errors.shape[2],T),:]
    fig,axes = plt.subplots(len(errs),1)
    if len(errs) == 1:
        axes = [axes]
    for a, ax in enumerate(axes):
        for m, method in enumerate(methods):
            ax.plot(errors[m,:,a],label=method.__name__)
        ax.set_ylabel(errs[a].__name__, fontsize=14)
        if a > 0:
            ax.legend(bbox_to_anchor=(0., 1.05, 1., .102), loc=3,
                      ncol=errors.shape[1], mode="expand", borderaxespad=0.)
    ax.set_xlabel('Iterations', fontsize=14)
    axes[0].set_title('Bellman Error vs Iteration for GTD Family', fontsize=18)
    plt.tight_layout(h_pad=3.0)
    return fig, axes


def plotErrors_MultipleRuns(errors,methods,errs,T=None):
    errors = np.asarray(errors)  # indexed by (run,methods,time,err)
    if T is not None:
        errors = errors[:,:,:min(errors.shape[2],T),:]
    t = np.arange(errors.shape[2])
    fig,axes = plt.subplots(len(errs),1)
    if len(errs) == 1:
        axes = [axes]
    for a, ax in enumerate(axes):
        for m, method in enumerate(methods):
            mean = np.mean(errors[:,m,:,a],axis=0)
            std = np.std(errors[:,m,:,a],axis=0)
            line, = ax.plot(mean,label=method.__name__)
            ax.fill_between(t, mean-std, mean+std, facecolor=line.get_color(),
                            alpha=0.3)
        ax.set_ylabel(errs[a].__name__, fontsize=14)
        if a > 0:
            ax.legend(bbox_to_anchor=(0., 1.05, 1., .102), loc=3,
                      ncol=errors.shape[1], mode="expand", borderaxespad=0.)
    ax.set_xlabel('Iterations', fontsize=14)
    axes[0].set_title('Bellman Error vs Iteration for GTD Family', fontsize=18)
    plt.tight_layout(h_pad=3.0)
    return fig, axes


def plotErrors_MultipleRunsZoom(errors,methods,errs,T=None,zoom=2.5,zoom_top=3):
    errors = np.asarray(errors)  # indexed by (run,methods,time,err)
    if T is not None:
        errors = errors[:,:,:min(errors.shape[2],T),:]
    t = np.arange(errors.shape[2])
    fig,axes = plt.subplots(len(errs),1)
    if len(errs) == 1:
        axes = [axes]
    for a, ax in enumerate(axes):
        axins = zoomed_inset_axes(ax, zoom, loc=1)
        y1 = np.inf
        y2 = []
        x1 = round(.9*t[-1])
        x2 = t[-1]
        for m, method in enumerate(methods):
            mean = np.mean(errors[:,m,:,a],axis=0)
            std = np.std(errors[:,m,:,a],axis=0)
            lo,hi = mean-std,mean+std

            line, = ax.plot(mean,label=method.__name__)
            ax.fill_between(t, lo, hi, facecolor=line.get_color(), alpha=0.3)
            line, = axins.plot(mean)
            axins.fill_between(t, lo, hi, facecolor=line.get_color(), alpha=0.3)

            y1 = min(y1,min(lo[x1:x2]))
            if m == 0:
                y2 = [max(hi[x1:x2])]*zoom_top
            else:
                y2 += [max(hi[x1:x2])]
                y2 = sorted(y2)[:zoom_top]

        y2 = max(y2)
        axins.set_xlim(x1, x2)
        axins.set_ylim(y1, y2)
        axins.get_xaxis().set_visible(False)
        axins.get_yaxis().set_visible(False)
        mark_inset(ax, axins, loc1=1, loc2=3, fc='none', ec='k', lw=1,
                   zorder=np.inf)

        ax.set_ylabel(errs[a].__name__, fontsize=14)
        if a > 0:
            ax.legend(bbox_to_anchor=(0., 1.05, 1., .102), loc=3,
                      ncol=errors.shape[1], mode="expand", borderaxespad=0.)

    ax.set_xlabel('Iterations', fontsize=14)
    axes[0].set_title('Bellman Error vs Iteration for GTD Family', fontsize=18)
    plt.tight_layout(h_pad=3.0)

    return fig, axes


def plotErrors_4Paper(errors,methods,errs,T=None,zoom=2.5,zoom_top=3):
    errors = np.asarray(errors)  # indexed by (run,methods,time,err)
    if T is not None:
        errors = errors[:,:,:min(errors.shape[2],T),:]
    t = np.arange(errors.shape[2])
    methMap = methStrMap()
    figs,axes = [],[]
    for e in xrange(len(errs)):
        fig = plt.figure()
        ax = plt.subplot(111)
        figs += [fig]
        axes += [ax]
        axins = zoomed_inset_axes(ax, zoom, loc=1)
        y1 = np.inf
        y2 = []
        x1 = round(.9*t[-1])
        x2 = t[-1]
        for m, method in enumerate(methods):
            mean = np.mean(errors[:,m,:,e],axis=0)
            std = np.std(errors[:,m,:,e],axis=0)
            lo,hi = mean-std,mean+std

            # line, = ax.plot(mean,label=method.__name__)
            line, = ax.plot(mean,label=methMap[method])
            ax.fill_between(t, lo, hi, facecolor=line.get_color(), alpha=0.3)
            line, = axins.plot(mean)
            axins.fill_between(t, lo, hi, facecolor=line.get_color(), alpha=0.3)

            y1 = min(y1,min(lo[x1:x2]))
            if m == 0:
                y2 = [max(hi[x1:x2])]*zoom_top
            else:
                y2 += [max(hi[x1:x2])]
                y2 = sorted(y2)[:zoom_top]

        y2 = max(y2)
        axins.set_xlim(x1, x2)
        axins.set_ylim(y1, y2)
        axins.get_xaxis().set_visible(False)
        axins.get_yaxis().set_visible(False)
        mark_inset(ax, axins, loc1=1, loc2=3, fc='none', ec='k', lw=1,
                   zorder=np.inf)
        ax.set_ylabel(errs[e].__name__, fontsize=14)
        ax.legend(loc=9)

        ax.set_xlabel('Iterations', fontsize=14)
        ax.set_title('Energy Management Domain', fontsize=18)
        plt.tight_layout(h_pad=3.0)

    return figs, axes


def Demo_SingleRun():
    print('\nLoading Data...')
    data = scipy.io.loadmat('energy_storage_martingale_symmetric_2000_runs.mat')
    r = data['rewards'].squeeze()
    phi = data['sampled_features'][:-1]
    phi_nxt = data['sampled_features'][1:]
    print('Done.\n')

    gam = .99
    rho = 1.

    methods = [etd0]  # [td,gtd,gtd2,gtdmp,gtd2mp]
    errs = [MSBE,MSPBE]
    alpha = .05
    T = 1000

    y0 = np.ones_like(phi[0])
    theta0 = np.ones_like(phi[0])

    stdout.write('Learning Weights... ')
    ys, thetas, errors = learnWeights(y0,theta0,methods,errs,r,phi,phi_nxt,
                                      alpha,T,gam,rho,
                                      testsize=1000)
    print('Done.')

    fig, axes = plotErrors(errors,methods,errs)
    plt.show()


def Demo_MultipleRuns(runs=10):
    print('\nLoading Data...')
    data = scipy.io.loadmat('energy_storage_martingale_symmetric_2000_runs.mat')
    r = data['rewards'].squeeze()
    phi = data['sampled_features'][:-1]
    phi_nxt = data['sampled_features'][1:]
    print('Done.\n')

    gam = .99
    rho = 1.

    methods = [td,gtd,gtd2,gtdmp,gtd2mp]
    errs = [MSBE,MSPBE]
    alpha = .05
    T = 100000

    y0 = np.ones_like(phi[0])
    theta0 = np.ones_like(phi[0])

    YS = []
    THETAS = []
    ERRORS = []

    for run in xrange(runs):
        stdout.write('Run '+repr(run+1)+': Learning Weights... ')
        ys, thetas, errors = learnWeights(y0,theta0,methods,errs,r,phi,phi_nxt,
                                          alpha,T,gam,rho,
                                          testsize=10000)
        YS += [ys]
        THETAS += [thetas]
        ERRORS += [errors]
    print('Done.')

    hyperparams = [gam,rho,methods,errs,alpha,T,y0,theta0]
    results = [YS,THETAS,ERRORS,hyperparams]
    np.save(timeStamped('Energy.npy'),results)

    fig, axes = plotErrors_MultipleRuns(ERRORS,methods,errs)
    plt.savefig(timeStamped('Energy.png'))


if __name__ == '__main__':
    plt.ioff()
    Demo_MultipleRuns(runs=2)
    # Demo_SingleRun()
