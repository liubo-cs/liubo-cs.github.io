from sys import stdout
import numpy as np
from Inventory import Simulator, DefaultConfiguration
import matplotlib.pyplot as plt
import datetime
from IPython import embed


# For time stamps
def timeStamped(fname, fmt='%Y-%m-%d-%H-%M-%S_{fname}'):
    return datetime.datetime.now().strftime(fmt).format(fname=fname)


def behaviorSampleGenerator(N,battery):
    # Initial state is fixed
    inventory = battery.initial_inventory
    capacity = battery.initial_capacity
    priceindex = 0
    init_state = (inventory,capacity,priceindex)
    absorb = False

    # Initialize state and next state
    decstate = init_state
    next_decstate = init_state

    samples = 0
    while samples < N:
        # Shift state to next state
        decstate = next_decstate

        # Detect absorbing state (negligible capacity) and restart
        if decstate[1] < battery._action_step:
            decstate = init_state
            absorb = True

        # Draw random action uniformly
        action = np.random.choice(battery.actions(decstate))
        deviation = np.abs(battery.all_actions()-action)
        action_index = np.where(deviation < battery._action_step/2.)[0][0]

        # Compute expected next state
        expstate = battery.transition_dec(decstate,action)
        # Realize next state (price transitions are stochastic)
        reward, next_decstate = battery.transition_exp(expstate)

        # Increment sample count
        samples += 1

        yield decstate, action_index, next_decstate, reward, absorb


def evalPolicy(N,battery,theta,w):
    # Initial state is fixed
    inventory = battery.initial_inventory
    capacity = battery.initial_capacity
    priceindex = 0
    init_state = (inventory,capacity,priceindex)
    phi = initFeatureTensor(battery,w)

    # Initialize state and next state
    decstate = init_state
    next_decstate = init_state

    # Drain Count
    drained = 0

    # Total reward
    R = 0

    # For finding available action indices
    limit = battery._action_step/2.

    samples = 0
    while samples < N:
        # Shift state to next state
        decstate = next_decstate

        # Detect absorbing state (negligible capacity) and restart
        if decstate[1] < battery._action_step:
            drained += 1  # increment drainage counter
            decstate = init_state

        # Retrieve available actions with corresponding indices
        available_actions = battery.actions(decstate)
        indices = []
        for a in available_actions:
            deviation = np.abs(battery.all_actions()-a) < limit
            indices += [np.where(deviation)[0][0]]

        # Calculate Q value for each action
        phi = updateFeatures(decstate,phi,w)
        Qs = Qvalues(phi,theta)[indices]

        # Choose action with maximum Q value
        avail_action_index = np.argmax(Qs)
        action = available_actions[avail_action_index]

        # Compute expected next state
        expstate = battery.transition_dec(decstate,action)
        # Realize next state (price transitions are stochastic)
        reward, next_decstate = battery.transition_exp(expstate)
        R += reward  # accrue reward

        # Increment sample count
        samples += 1

    return drained, R


def generateSamples(T,battery):
    bsg = behaviorSampleGenerator(T,battery)
    return [sample for sample in bsg]


def initFeatureTensor(battery,w):
    featTensor = np.zeros((3,len(w),len(battery.price_buy)))
    return featTensor


def updateFeatures(decstate,featTensor,w):
    # Extract x, s, theta from state
    inventory, capacity, priceindex = decstate

    # Clear feature tensor
    featTensor *= 0.

    # Populate tensor with new features
    featTensor[0,:,priceindex] = inventory - w
    featTensor[1,:,priceindex] = capacity - w
    featTensor[2,:,priceindex] = capacity + inventory - w

    return featTensor


def Qvalues(phi,theta):
    # Phi indexed by (type,w_index,price_index)
    # Theta indexed by (action,type,w_index,price_index)
    return np.sum(theta*phi,axis=(1,2,3))


def GreedyGQ(lam,shuffle=False):
    # Initialize simulator
    battery = Simulator(DefaultConfiguration)

    # Iteration limits
    T = int(1e4)  # Learning iterations
    _T = int(1e4)  # Evaluation iterations
    trials = 10  # Evaluation trials
    freq = 100  # Evaluation frequency

    # discount rate (gam), behavior policy (pi_b)
    gam = battery.discount
    num_actions = len(battery.all_actions())
    pi_b = 1./num_actions
    hyps = (gam,lam,pi_b)

    # Initialize feature basis vectors
    w = np.linspace(0,1,11)
    phi = initFeatureTensor(battery,w)

    # Initialize policy weight, dual weight, eligibility trace
    theta0 = np.zeros((num_actions,)+phi.shape)
    y0 = np.zeros((num_actions,)+phi.shape)
    e0 = np.zeros_like(phi)

    # Initialize learning methods
    x_TD = (theta0.copy(),None,e0.copy())
    x_GQMP = (theta0.copy(),y0.copy(),e0.copy())
    x_GTDQMP = (theta0.copy(),y0.copy(),e0.copy())

    # Initialize custom learning rates
    alpha_TD = 1e-3
    alpha_GQMP = 1e-3
    alpha_GTDQMP = 1e-3

    # Prepend learning rates (alphas) to hyperparameters
    hyps_TD = (alpha_TD,) + hyps
    hyps_GQMP = (alpha_GQMP,) + hyps
    hyps_GTDQMP = (alpha_GTDQMP,) + hyps

    # Initialize lists to record weights and evaluation criteria
    thetas = []
    errs = []
    drains = []
    drain_std = []
    total_rewards = []
    total_r_std = []

    # Window size - Usually ruins performance, keep @ 1
    win_len = 1

    # Draw samples and shuffle if necessary
    bsg = behaviorSampleGenerator(T,battery)
    if shuffle:
        samples = [sample for sample in bsg]
        training_set = np.random.permutation(samples)
    else:
        training_set = bsg

    # Improve policies
    completed = ''
    for t, sample in enumerate(training_set):
        stdout.write('\b'*len(completed)+'%d/%d' % (t+1,T))
        stdout.flush()
        completed = '{0}/{1}'.format(t+1,T)

        # Retrieve sample transition information
        state, action_index, next_state, reward, absorb = sample

        # Record weights
        thetas += [[x_TD[0].copy(),x_GQMP[0].copy(),x_GTDQMP[0].copy()]]
        # thetas += [[x_TD[0].copy(),x_GQMP[0].copy()]]

        # Calculate average drainage and total reward for current weights
        if t % freq == 0:
            drain = [[] for theta in thetas[-1]]
            total_r = [[] for theta in thetas[-1]]
            for trial in xrange(trials):
                for idx in xrange(len(thetas[-1])):
                    window = min(len(thetas),win_len)
                    _theta = np.mean([p[idx] for p in thetas[-window:]],axis=0)
                    num_drains, total_reward = evalPolicy(_T,battery,_theta,w)
                    drain[idx] += [num_drains]
                    total_r[idx] += [total_reward]
            drains += [[np.mean(d) for d in drain]]
            total_rewards += [[np.mean(r) for r in total_r]]
            drain_std += [[np.std(d) for d in drain]]
            total_r_std += [[np.std(r) for r in total_r]]

        # Construct features from state transition
        phi = updateFeatures(state,phi,w)
        next_phi = updateFeatures(next_state,phi.copy(),w)
        transition = (phi,action_index,next_phi,reward,absorb)

        # Perform policy updates
        x_TD, MSBE_TD = TDLearn(x_TD,transition,hyps_TD)
        x_GQMP, MSBE_GQMP = GQLearnMP2(x_GQMP,transition,hyps_GQMP)
        x_GTDQMP, MSBE_GTDQMP = GTDQ_MP(x_GTDQMP,transition,hyps_GTDQMP)

        # Record MSBE for initial weights (not newly learned weights)
        errs += [[MSBE_TD,MSBE_GQMP,MSBE_GTDQMP]]
        # errs += [[MSBE_TD,MSBE_GQMP]]
    stdout.write('\n')

    errs = np.asarray(errs)
    drains = np.asarray(drains)
    total_rewards = np.asarray(total_rewards)
    drain_std = np.asarray(drain_std)
    total_r_std = np.asarray(total_r_std)

    return thetas, errs, drains, total_rewards, drain_std, total_r_std


# PI helper function
def td_error_Qs(r,gam,Q,next_Q):
    return r + gam*next_Q - Q


def TDLearn(x,transition,hyps):
    # Unpack arguments
    theta,y,e = x
    phi,a_index,next_phi,reward,absorb = transition
    alpha, gam, lam, pi_b = hyps

    # Reset eligibility if sim restarting from absorbing state
    if absorb:
        e = np.zeros_like(phi)

    # Calculate Q value for each action
    Qs = Qvalues(phi,theta)

    # Retrieve Q value of action taken
    Q = Qs[a_index]

    # Was optimal action taken? Update importance weight
    opt_action = (a_index in np.where(Qs == np.max(Qs))[0])
    rho = opt_action/pi_b

    # Calculate max Q value for next state
    next_Q = np.max(Qvalues(next_phi,theta))

    # Calculate MSBE for current theta
    MSBE = np.linalg.norm(next_Q-Q)

    # Retrieve theta associated with action taken
    theta_t = theta[a_index]

    # Calculate eligibility
    e = gam*lam*rho*e + phi

    # Calclulate td error
    td_err = td_error_Qs(rho*reward,gam,Q,rho*next_Q)

    # Calculate new theta
    theta[a_index] = theta_t + alpha*e*td_err

    return [theta, y, e], MSBE


def GQLearn(x,transition,hyps):
    # Unpack arguments
    theta,y,e = x
    phi,a_index,next_phi,reward,absorb = transition
    alpha, gam, lam, pi_b = hyps

    # Reset eligibility if sim restarting from absorbing state
    if absorb:
        e = np.zeros_like(phi)

    # Calculate Q value for each action
    Qs = Qvalues(phi,theta)

    # Retrieve Q value of action taken
    Q = Qs[a_index]

    # Was optimal action taken? Update importance weight
    opt_action = (a_index in np.where(Qs == np.max(Qs))[0])
    rho = opt_action/pi_b

    # Calculate max Q value for next state
    next_Q = np.max(Qvalues(next_phi,theta))

    # Calculate MSBE for current theta
    MSBE = np.linalg.norm(next_Q-Q)

    # Retrieve theta, y associated with action taken
    theta_t = theta[a_index]
    y_t = y[a_index]

    # Calculate eligibility
    e = gam*lam*rho*e + phi

    # Calclulate td error
    td_err = td_error_Qs(rho*reward,gam,Q,rho*next_Q)

    # Calculate new y
    Q_y = np.sum(phi*y_t)
    y[a_index] = y_t + alpha*(e*td_err - Q_y*phi)

    # Calculate new theta
    ey = np.sum(e*y_t)
    theta[a_index] = theta_t + alpha*(phi*Q_y - rho*gam*(1-lam)*ey*next_phi)

    return (theta, y, e), MSBE


def GQLearnMPOld(x,transition,hyps):
    # Unpack arguments
    theta,y,e = x
    phi,a_index,next_phi,reward,absorb = transition
    alpha, gam, lam, pi_b = hyps

    # Reset eligibility if sim restarting from absorbing state
    if absorb:
        e = np.zeros_like(phi)

    # Calculate Q value for each action
    Qs = Qvalues(phi,theta)

    # Retrieve Q value of action taken
    Q = Qs[a_index]

    # Was optimal action taken? Update importance weight
    opt_action = (a_index in np.where(Qs == np.max(Qs))[0])
    rho = opt_action/pi_b

    # Calculate max Q value for next state
    next_Q = np.max(Qvalues(next_phi,theta))

    # Calculate MSBE for current theta
    MSBE = np.linalg.norm(next_Q-Q)

    # Retrieve theta, y associated with action taken
    theta_t = theta[a_index]
    y_t = y[a_index]

    # Calculate eligibility
    e = gam*lam*rho*e + phi

    # Calclulate td error
    td_err = td_error_Qs(reward,gam,Q,next_Q)

    # Calculate y_mid
    Q_y = np.sum(phi*y_t)
    y_m = y_t + alpha*(e*td_err - Q_y*phi)

    # Calculate theta_mid
    ey = np.sum(e*y_t)
    theta_m = theta_t + alpha*(phi*Q_y - rho*gam*(1-lam)*ey*next_phi)

    # Calculate td_error_mid
    Q_m = np.sum(theta_m*phi)
    theta_m_full = theta.copy()
    theta_m_full[a_index] = theta_m
    next_Q_m = np.max(Qvalues(next_phi,theta_m_full))
    td_err_m = td_error_Qs(reward,gam,Q_m,next_Q_m)

    # Calculate new y
    Q_y_m = np.sum(phi*y_m)
    y[a_index] = y_t + alpha*(e*td_err_m - Q_y_m*phi)

    # Calculate new theta
    ey_m = np.sum(e*y_m)
    theta[a_index] = theta_t + alpha*(phi*Q_y_m - rho*gam*(1-lam)*ey_m*next_phi)

    return (theta, y, e), MSBE


def GQLearnMP(x,transition,hyps):
    # Unpack arguments
    theta,y,e = x
    phi,a_index,next_phi,reward,absorb = transition
    alpha, gam, lam, pi_b = hyps

    # Reset eligibility if sim restarting from absorbing state
    if absorb:
        e = np.zeros_like(phi)

    # Calculate Q value for each action
    Qs = Qvalues(phi,theta)

    # Retrieve Q value of action taken
    Q = Qs[a_index]

    # Was optimal action taken? Update importance weight
    opt_action = (a_index in np.where(Qs == np.max(Qs))[0])
    rho = opt_action/pi_b

    # Calculate max Q value for next state
    next_Q = np.max(Qvalues(next_phi,theta))

    # Calculate MSBE for current theta
    MSBE = np.linalg.norm(next_Q-Q)

    # Retrieve theta, y associated with action taken
    theta_t = theta[a_index]
    y_t = y[a_index]

    # Calculate eligibility
    e = gam*lam*rho*e + phi

    # compute delta_phi
    delta_phi = (phi-gam*next_phi)

    # Calclulate td error
    td_err = td_error_Qs(rho*reward,gam,Q,rho*next_Q)

    # Calculate y_mid
    Q_y = np.sum(phi*y_t)
    y_m = y_t + alpha*(e*td_err - Q_y*phi)

    # Calculate theta_mid
    ey = np.sum(e*y_t)
    theta_m = theta_t + alpha*delta_phi*ey

    # Calculate td_error_mid
    Q_m = np.sum(theta_m*phi)
    theta_m_full = theta.copy()
    theta_m_full[a_index] = theta_m
    next_Q_m = np.max(Qvalues(next_phi,theta_m_full))
    td_err_m = td_error_Qs(rho*reward,gam,Q_m,rho*next_Q_m)

    # Calculate new y
    Q_y_m = np.sum(phi*y_m)
    y[a_index] = y_t + alpha*(e*td_err_m - Q_y_m*phi)

    # Calculate new theta
    ey_m = np.sum(e*y_m)
    theta[a_index] = theta_t + alpha*delta_phi*ey_m

    return (theta, y, e), MSBE


def GQLearnMP2(x,transition,hyps):
    # Unpack arguments
    theta,y,e = x
    phi,a_index,next_phi,reward,absorb = transition
    alpha, gam, lam, pi_b = hyps

    # Reset eligibility if sim restarting from absorbing state
    if absorb:
        e = np.zeros_like(phi)

    # Calculate Q value for each action
    Qs = Qvalues(phi,theta)

    # Retrieve Q value of action taken
    Q = Qs[a_index]

    # Was optimal action taken? Update importance weight
    opt_action = (a_index in np.where(Qs == np.max(Qs))[0])
    rho = opt_action/pi_b

    # Calculate max Q value for next state
    next_Q = np.max(Qvalues(next_phi,theta))

    # Calculate MSBE for current theta
    MSBE = np.linalg.norm(next_Q-Q)

    # Retrieve theta, y associated with action taken
    theta_t = theta[a_index]
    y_t = y[a_index]

    # Calculate eligibility
    e = gam*lam*rho*e + phi

    # compute delta_phi
    delta_phi = (phi-gam*next_phi)

    # Calclulate td error
    td_err = td_error_Qs(reward,gam,Q,next_Q)

    # Calculate y_mid
    Q_y = np.sum(phi*y_t)
    y_m = y_t + alpha*(rho*e*td_err - Q_y*phi)

    # Calculate theta_mid
    ey = np.sum(e*y_t)
    theta_m = theta_t + alpha*rho*delta_phi*ey

    # Calculate td_error_mid
    Q_m = np.sum(theta_m*phi)
    theta_m_full = theta.copy()
    theta_m_full[a_index] = theta_m
    next_Q_m = np.max(Qvalues(next_phi,theta_m_full))
    td_err_m = td_error_Qs(reward,gam,Q_m,next_Q_m)

    # Calculate new y
    Q_y_m = np.sum(phi*y_m)
    y[a_index] = y_t + alpha*(rho*e*td_err_m - Q_y_m*phi)

    # Calculate new theta
    ey_m = np.sum(e*y_m)
    theta[a_index] = theta_t + alpha*rho*delta_phi*ey_m

    return (theta, y, e), MSBE


'''
GTDQ_MP is the control learning version of GTD algorithm
'''


def GTDQ_MP(x,transition,hyps):
    # Unpack arguments
    theta,y,e = x
    phi,a_index,next_phi,reward,absorb = transition
    alpha, gam, lam, pi_b = hyps

    # Reset eligibility if sim restarting from absorbing state
    if absorb:
        e = np.zeros_like(phi)

    # Calculate Q value for each action
    Qs = Qvalues(phi,theta)

    # Retrieve Q value of action taken
    Q = Qs[a_index]

    # Was optimal action taken? Update importance weight
    opt_action = (a_index in np.where(Qs == np.max(Qs))[0])
    rho = opt_action/pi_b

    # Calculate max Q value for next state
    next_Q = np.max(Qvalues(next_phi,theta))

    # Calculate MSBE for current theta
    MSBE = np.linalg.norm(next_Q-Q)

    # Retrieve theta, y associated with action taken
    theta_t = theta[a_index]
    y_t = y[a_index]

    # Calculate eligibility
    e = gam*lam*rho*e + phi

    # compute delta_phi
    delta_phi = (phi-gam*next_phi)

    # Calclulate td error
    td_err = td_error_Qs(reward,gam,Q,next_Q)

    # Calculate y_mid
    # Q_y = np.sum(phi*y_t)
    y_m = y_t + alpha*(rho*e*td_err - y_t)

    # Calculate theta_mid
    ey = np.sum(e*y_t)
    theta_m = theta_t + alpha*rho*delta_phi*ey

    # Calculate td_error_mid
    Q_m = np.sum(theta_m*phi)
    theta_m_full = theta.copy()
    theta_m_full[a_index] = theta_m
    next_Q_m = np.max(Qvalues(next_phi,theta_m_full))
    td_err_m = td_error_Qs(reward,gam,Q_m,next_Q_m)

    # Calculate new y
    # Q_y_m = np.sum(phi*y_m)
    y[a_index] = y_t + alpha*(rho*e*td_err_m - y_m)

    # Calculate new theta
    ey_m = np.sum(e*y_m)
    theta[a_index] = theta_t + alpha*rho*delta_phi*ey_m

    return (theta, y, e), MSBE

if __name__ == '__main__':
    # Learn policies for various methods and retrieve evaluation criteria
    results = GreedyGQ(0)
    np.save(timeStamped('PI.npy'),results)
    thetas, errs, drains, rewards, drain_std, reward_std = results

    # Plot evaluation criteria
    meths = ['TD','GQMP','GTDQMP']

    # Xlimit
    Xlimit = 7000

    for m in xrange(errs.shape[1]):
        plt.semilogy(errs[:,m],label=meths[m])
    plt.xlabel('Steps')
    plt.ylabel('MSBE')
    plt.xlim([0,Xlimit])
    z = plt.axis()
    plt.ylim([z[2],np.max(errs[:Xlimit])])
    plt.legend(loc='upper left')
    plt.show()

    for report in [(drains,drain_std),(rewards,reward_std)]:
        fig = plt.figure()
        ax = plt.subplot(111)
        for m in xrange(report[0].shape[1]):
            mean = report[0][:,m]
            std = report[1][:,m]

            t = np.linspace(0,len(thetas),mean.shape[0])

            lo,hi = mean-std,mean+std

            line, = ax.plot(t,mean,label=meths[m])
            ax.fill_between(t,lo,hi,facecolor=line.get_color(),alpha=0.5)
        plt.xlabel('Steps')
        if report[0] is drains:
            plt.ylabel('# Of Battery Drains')
        else:
            plt.ylabel('Total Reward')
        plt.legend()
        plt.xlim([0,Xlimit])
        plt.show()

    embed()
