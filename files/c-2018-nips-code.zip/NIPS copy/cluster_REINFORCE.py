import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA

import matplotlib.pyplot as plt

from util import *
from Portfolio import *
from American_Option import *
from Optimal_Stopping import *
from cluster_Prob_Dist_Test import *

# import autograd.numpy as np  # Thinly-wrapped numpy
# from autograd import grad    # The only autograd function you may ever need

np.set_printoptions(precision=3,suppress=True)
#################################################
# Hyperparameters
e = 0.1 # e greedy policy
H = 20000 # Horizon
trails_num = 1
episode_num = 4000

IfPrint = False # True, False

environment = "Portfolio" # Portfolio, American_Option, Optimal_Stopping
#################################################

if environment == "Portfolio":
    env = Portfolio()
    policy = env.ep_binary_policy # policy(theta,s)
    eta = 0.01 # learning rate

if environment == "American_Option":
    env = American_Option()
    policy = env.binary_policy # policy(theta,s)
    eta = 0.01 # learning rate

if environment == "Optimal_Stopping":
    env = Optimal_Stopping()
    policy = env.binary_policy # policy(theta,s)
    eta = 0.001 # learning rate


def choose_action(act_dist):
    action_choices = len(act_dist)
    action = np.random.choice(action_choices,p=act_dist)
    return action


def Portfolio_main():
    para = sys.argv
    i = int(para[1])
    stepsize = float(para[2])
    eta = stepsize

    total_r = []
    s = env.reset()
    feature = env.phi(s)
    theta = feature * 0
    # theta = np.random.randn(len(feature))
    # p.start(episode_num)
    for episode in xrange(episode_num):
        # p.update(episode+1)
        # if episode % 10 == 0:
        if episode % 10 == 0 and episode > 0 and IfPrint:
            print "episode: ", episode
            print total_reward
        s = env.reset()
        IfEnd = False
        total_reward = 0
        grad_logpolicy = theta * 0
        while not IfEnd:
            # feature = env.phi(s)
            act_dist = policy(theta,s)
            a = choose_action(act_dist)
            s, r, IfEnd = env.next_step(s,a)
            total_reward += r
            grad_logpolicy += env.grad_log_policy(theta,s,a,act_dist)
        total_reward += env.ini_money
        total_reward = np.log(total_reward)
        total_r.append(total_reward)
        # print total_reward
        control = np.mean(total_r)
        control = 29.5
        theta += eta * (total_reward - control) * grad_logpolicy
    # p.finish()
    savename = "./" + environment + "_policy/REINFORCE/_" + str(eta) + "_" + str(episode_num) +  "_/REINFORCE_theta_" + str(i) + ".txt"
    ensure_dir(savename)
    np.savetxt(savename,theta)
    if IfPrint:
        plt.figure(1)
        plt.plot(total_r,'b-',label = 'REINFORCE')
        plt.show()

    value = Portfolio_run_once(theta)
    savevalue = "./" + environment + "_policy/REINFORCE/_" + str(eta) + "_" + str(episode_num) +  "_/REINFORCE_value_" + str(i) + ".txt"
    np.savetxt(savevalue,np.array(value).reshape(1,))

def American_Option_main():

    para = sys.argv
    i = int(para[1])
    stepsize = float(para[2])
    eta = stepsize

    total_r = []
    s = env.reset()
    feature = env.phi(s)
    theta = feature * 0
    for episode in xrange(episode_num):
        # if episode % 10 == 0:
        if episode % 10 == 0 and episode > 0 and IfPrint:
            print "episode: ", episode
            print total_reward
        s = env.reset()
        IfEnd = False
        total_reward = 0
        grad_logpolicy = theta * 0
        while not IfEnd:
            # feature = env.phi(s)
            act_dist = policy(theta,s)
            a = choose_action(act_dist)
            s, r, IfEnd = env.next_step(s,a)
            # total_reward += r
            grad_logpolicy += env.grad_log_policy(theta,s,a,act_dist)
            total_reward += r
        total_r.append(total_reward)
        # print total_reward
        control = np.mean(total_r)
        theta += eta * (total_reward - control) * grad_logpolicy
    savename = "./" + environment + "_policy/REINFORCE/_" + str(eta) + "_" + str(episode_num) +  "_/REINFORCE_theta_" + str(i) + ".txt"
    ensure_dir(savename)
    np.savetxt(savename,theta)
    if IfPrint:
        plt.figure(1)
        plt.plot(total_r,'b-',label = 'REINFORCE')
        plt.show()

    value = American_Option_run_once(theta)
    savevalue = "./" + environment + "_policy/REINFORCE/_" + str(eta) + "_" + str(episode_num) +  "_/REINFORCE_value_" + str(i) + ".txt"
    np.savetxt(savevalue,np.array(value).reshape(1,))

if environment == "Portfolio":
    main = Portfolio_main
if environment == "American_Option" or environment == "Optimal_Stopping":
    main = American_Option_main

if __name__ == '__main__':
    main()
    print "Succeed!"
