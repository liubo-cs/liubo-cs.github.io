import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA
import seaborn as sns
from scipy.stats import norm
# import progressbar
# p = progressbar.ProgressBar()

import matplotlib.pyplot as plt

from util import *
from Portfolio import *
from American_Option import *
from Optimal_Stopping import *

sns.set_context("poster",font_scale=1.9)
sns.set_style("ticks")

np.set_printoptions(precision=3,suppress=True)
#################################################
# Hyperparameters
e = 0.1 # e greedy policy
eta = 0.0001 # learning rate
etay = 0.0001 # learning rate
H = 20000 # Horizon
trails_num = 30
episode_num = 10000

episode_num_forpath1 = 4000 # REINFORCE
episode_num_forpath = 4000 # MVP
episode_num_forpath2 = 4000 # Tamar

etar = 0.06 # REINFORCE
eta = 0.003 # MVP
alpha = 0.06 # Tamar
alpharcpg = 0.02 # RCPG
alpharcpg2 = 0.003 # SGD

lbd = 0.1
lbd1 = 0.3 # RCPG
lbd2 = 0.1 # SGD

IfControl = False

environment = "American_Option" # Portfolio, American_Option

IfHist = False # True, False
#################################################

if environment == "Portfolio":
    env = Portfolio()
    policy = env.binary_policy # policy(theta,s)
if environment == "American_Option":
    env = American_Option()
    policy = env.binary_policy # policy(theta,s)
if environment == "Optimal_Stopping":
    env = Optimal_Stopping()
    policy = env.binary_policy # policy(theta,s)

if __name__ == '__main__':
    all_REINFORCE_return = []
    all_MVP_return = []
    all_Tamar_return = []
    all_RCPG_return = []
    all_SGD_return = []

    # print "trail#: "

    # p.start(trails_num)
    for i in xrange(trails_num):
        # p.update(i+1)
        REINFORCE_savename = savename = "./" + environment + "_policy/REINFORCE/_" + str(etar) + "_" + str(episode_num_forpath1) +  "_/REINFORCE_value_" + str(i) + ".txt"
        MVP_savename = "./" + environment + "_policy/MVP/_" + "lbd" + str(lbd) + "_" + str(eta) + "_" + str(episode_num_forpath) + str(IfControl) + "_/MVP_value_" + str(i) + ".txt"
        Tamar_savename = "./" + environment + "_policy/Tamar/_" + str(alpha) + "_" + str(episode_num_forpath2) +  "_/Tamar_value_" + str(i) + ".txt"
        RCPG_savename = "./" + environment + "_policy/RCPG/_" + "lbd" + str(lbd1) + "_" + str(alpharcpg) + "_" + str(episode_num_forpath) + str(IfControl) + "_/RCPG_value_" + str(i) + ".txt"
        SGD_savename = "./" + environment + "_policy/SGD/_" + "lbd" + str(lbd2) + "_" + str(alpharcpg2) + "_" + str(episode_num_forpath) + str(IfControl) + "_/RCPG_value_" + str(i) + ".txt"

        REINFORCE_value = np.loadtxt(REINFORCE_savename)
        MVP_value = np.loadtxt(MVP_savename)
        Tamar_value = np.loadtxt(Tamar_savename)
        RCPG_value = np.loadtxt(RCPG_savename)
        SGD_value = np.loadtxt(SGD_savename)

        all_REINFORCE_return.append(REINFORCE_value)
        # print "MVP: "
        all_MVP_return.append(MVP_value)
        # print "Tamar: "
        all_Tamar_return.append(Tamar_value)
        all_RCPG_return.append(RCPG_value)
        all_SGD_return.append(SGD_value)
    # p.finish()

    all_REINFORCE_return.sort()
    all_MVP_return.sort()
    all_Tamar_return.sort()
    all_RCPG_return.sort()
    all_SGD_return.sort()

    all_REINFORCE_return = all_REINFORCE_return[:]
    all_MVP_return = all_MVP_return[:]
    all_Tamar_return = all_Tamar_return[:]
    all_RCPG_return = all_RCPG_return[:]
    all_SGD_return = all_SGD_return[:]

    REINFORCE_mu, REINFORCE_sig = norm.fit(all_REINFORCE_return)
    MVP_mu, MVP_sig = norm.fit(all_MVP_return)
    Tamar_mu, Tamar_sig = norm.fit(all_Tamar_return)
    RCPG_mu, RCPG_sig = norm.fit(all_RCPG_return)
    SGD_mu, SGD_sig = norm.fit(all_SGD_return)

    alphas = np.linspace(0.001,1, 500) # significance level
    def getVaRCVaR(mu_norm,sig_norm):
        CVaR = []
        VaR = []
        for alpha in alphas:
            #lev = 100*(1-alpha)
            CVaR_n = -(alpha**-1 * norm.pdf(norm.ppf(alpha))*sig_norm - mu_norm)
            VaR_n = -(norm.ppf(1-alpha)*sig_norm - mu_norm)
            #VaR_n = norm.ppf(1-alpha)
            CVaR.append(CVaR_n)
            VaR.append(VaR_n)
        return CVaR,VaR

    REINFORCE_CVaR,REINFORCE_VaR = getVaRCVaR(REINFORCE_mu, REINFORCE_sig)
    MVP_CVaR,MVP_VaR = getVaRCVaR(MVP_mu, MVP_sig)
    Tamar_CVaR,Tamar_VaR = getVaRCVaR(Tamar_mu, Tamar_sig)
    RCPG_CVaR,RCPG_VaR = getVaRCVaR(RCPG_mu, RCPG_sig)
    SGD_CVaR,SGD_VaR = getVaRCVaR(SGD_mu, SGD_sig)


    mv1 = [200]
    mv2 = [60]
    mv3 = [100]
    mv4 = [170]
    mv5 = [50]
    msz = 20
    mew = 2.0

    fig = plt.figure(figsize=(12,9))
    plt.xlim(0,1)
    plt.plot(alphas, MVP_CVaR, '#e41a1c',linewidth=5, label='MVP',linestyle="solid",marker="o",markevery=mv1,markersize=msz,markeredgecolor="k",markeredgewidth=mew)
    plt.plot(alphas, SGD_CVaR, '#999999',linewidth=5, label='SGD',linestyle="--",marker="d",markevery=mv5,markersize=msz,markeredgecolor="k",markeredgewidth=mew,dashes=(1,0.5))
    plt.plot(alphas, Tamar_CVaR, '#4daf4a',linewidth=5, label='Tamar',linestyle="--",marker=">",markevery=mv4,markersize=msz,markeredgecolor="k",markeredgewidth=mew)
    plt.plot(alphas, REINFORCE_CVaR, '#377eb8',linewidth=5, label='REINFORCE',linestyle=":",marker="s",markevery=mv3,markersize=msz,markeredgecolor="k",markeredgewidth=mew)
    plt.plot(alphas, RCPG_CVaR, '#984ea3',linewidth=5, label='RCPG',linestyle="-.",marker="X",markevery=mv2,markersize=msz,markeredgecolor="k",markeredgewidth=mew)
    leg = plt.legend(loc=0,frameon=False,framealpha=1.0,edgecolor='k',ncol=2)
    leg.get_frame().set_linewidth(1.0)
    plt.ylabel(r'Accumulated Reward')
    plt.xlabel(r'Risk Level $(\alpha)$')
    sns.despine()
    fig.tight_layout()
    plt.show()
    fig.savefig("plots/CVaR_" + str(eta) + "_" + str(episode_num_forpath) +"_.pdf",bbox_inches='tight')
    print "Succeed!"
