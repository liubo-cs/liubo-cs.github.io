import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA

import matplotlib.pyplot as plt

from util import *
from Portfolio import *
from American_Option import *
from Optimal_Stopping import *
from cluster_Prob_Dist_Test import *

np.set_printoptions(precision=3,suppress=True)
#################################################
# Hyperparameters
e = 0.1 # e greedy policy
H = 20000 # Horizon
trails_num = 1
episode_num = 4000

lbd = 5.0

IfPrint = False # True, False

IfControl = False

environment = "American_Option" # Portfolio, American_Option, Optimal_Stopping
#################################################

if environment == "Portfolio":
    env = Portfolio()
    policy = env.binary_policy # policy(theta,s)
    eta = 0.01 # learning rate
    etay = 0.01 # learning rate

if environment == "American_Option":
    env = American_Option()
    policy = env.binary_policy # policy(theta,s)
    eta = 0.00025 # learning rate
    etay = 0.00025 # learning rate

if environment == "Optimal_Stopping":
    env = Optimal_Stopping()
    policy = env.binary_policy # policy(theta,s)
    eta = 0.001 # learning rate
    etay = 0.001 # learning rate


def choose_action(act_dist):
    action_choices = len(act_dist)
    action = np.random.choice(action_choices,p=act_dist)
    return action

def Portfolio_main():
    para = sys.argv
    i = int(para[1])
    stepsize = float(para[2])
    eta = stepsize
    etay = stepsize
    lbd = float(para[3])

    IfControl = bool(para[4])
    IfControl = False

    total_r = []
    total_r2 = []
    s = env.reset()
    feature = env.phi(s)
    theta = feature * 0
    y = 20
    for episode in xrange(episode_num):
        # if episode % 10 == 0:
        if episode % 10 == 0 and episode > 0 and IfPrint:
            print "episode: ", episode
            print total_reward
        s = env.reset()
        IfEnd = False
        total_reward = 0
        grad_logpolicy = theta * 0
        while not IfEnd:
            # feature = env.phi(s)
            act_dist = policy(theta,s)
            a = choose_action(act_dist)
            s, r, IfEnd = env.next_step(s,a)
            total_reward += r
            grad_logpolicy += env.grad_log_policy(theta,s,a,act_dist)
        total_reward += env.ini_money
        total_reward = np.log(total_reward)
        total_r.append(total_reward)
        total_r2.append(total_reward ** 2)
        control = np.mean(total_r) * float(IfControl)
        control2 = np.mean(total_r2) * float(IfControl)
        rdnb = np.random.randint(2)
        y1 = y + etay * (2 * total_reward + 1 / lbd - 2 * y) * rdnb
        theta += eta * (2 * y * (total_reward - control) - total_reward ** 2 + control2) * grad_logpolicy * (1 - rdnb)
        y = y1 + 0.0
        # y += etay * 2 * lbd * (total_reward - y)
        # theta += eta * ((1 + 2 * y * lbd) * (total_reward - control) - lbd * (total_reward ** 2 - control2)) * grad_logpolicy
    savename = "./" + environment + "_policy/RCPG/_" + "lbd" + str(lbd) + "_" + str(eta) + "_" + str(episode_num) + str(IfControl) +  "_/RCPG_theta_" + str(i) + ".txt"
    ensure_dir(savename)
    np.savetxt(savename,theta)
    if IfPrint:
        plt.figure(1)
        plt.plot(total_r,'r-',label = 'RCPG')
        plt.show()

    value = Portfolio_run_once(theta)
    savevalue = "./" + environment + "_policy/RCPG/_" + "lbd" + str(lbd) + "_" + str(eta) + "_" + str(episode_num)  + str(IfControl) +  "_/RCPG_value_" + str(i) + ".txt"
    np.savetxt(savevalue,np.array(value).reshape(1,))

def American_Option_main():
    para = sys.argv
    i = int(para[1])
    stepsize = float(para[2])
    eta = stepsize
    etay = stepsize
    lbd = float(para[3])

    IfControl = bool(para[4])
    IfControl = False

    total_r = []
    total_r2 = []
    s = env.reset()
    feature = env.phi(s)
    theta = feature * 0
    if environment == "American_Option":
        y = 0.5
    if environment == "Optimal_Stopping":
        y = 0.0
    for episode in xrange(episode_num):
        # if episode % 10 == 0:
        if episode % 10 == 0 and episode > 0 and IfPrint:
            print "episode: ", episode
            print total_reward
        s = env.reset()
        IfEnd = False
        total_reward = 0
        grad_logpolicy = theta * 0
        while not IfEnd:
            # feature = env.phi(s)
            act_dist = policy(theta,s)
            a = choose_action(act_dist)
            s, r, IfEnd = env.next_step(s,a)
            grad_logpolicy += env.grad_log_policy(theta,s,a,act_dist)
            total_reward += r
        total_r.append(total_reward)
        total_r2.append(total_reward ** 2)
        control = np.mean(total_r) * float(IfControl)
        control2 = np.mean(total_r2) * float(IfControl)
        rdnb = np.random.randint(2)
        y1 = y + etay * (2 * total_reward + 1 / lbd - 2 * y) * rdnb
        theta += eta * (2 * y * (total_reward - control) - total_reward ** 2 + control2) * grad_logpolicy * (1 - rdnb)
        y = y1 + 0.0
        # y += etay * 2 * lbd * (total_reward - y)
        # theta += eta * ((1 + 2 * y * lbd) * (total_reward - control) - lbd * (total_reward ** 2 - control2)) * grad_logpolicy
    # savename = "./American_Option_policy/RCPG/RCPG_theta_" + str(i) + ".txt"
    savename = "./" + environment + "_policy/RCPG/_" + "lbd" + str(lbd) + "_" + str(eta) + "_" + str(episode_num) + str(IfControl) +  "_/RCPG_theta_" + str(i) + ".txt"
    ensure_dir(savename)
    np.savetxt(savename,theta)
    if IfPrint:
        plt.figure(1)
        plt.plot(total_r,'r-',label = 'RCPG')
        plt.show()

    value = American_Option_run_once(theta)
    savevalue = "./" + environment + "_policy/RCPG/_" + "lbd" + str(lbd) + "_" + str(eta) + "_" + str(episode_num)  + str(IfControl) +  "_/RCPG_value_" + str(i) + ".txt"
    np.savetxt(savevalue,np.array(value).reshape(1,))

if environment == "Portfolio":
    main = Portfolio_main
if environment == "American_Option" or environment == "Optimal_Stopping":
    main = American_Option_main

if __name__ == '__main__':
    main()
    print "Succeed!"
