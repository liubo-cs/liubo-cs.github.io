import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA
import seaborn as sns
from scipy.stats import norm
# import progressbar
# p = progressbar.ProgressBar()

import matplotlib.pyplot as plt

from util import *
from Portfolio import *
from American_Option import *
from Optimal_Stopping import *

sns.set_context("poster",font_scale=1.9)
sns.set_style("ticks")

np.set_printoptions(precision=3,suppress=True)
#################################################
# Hyperparameters
e = 0.1 # e greedy policy
eta = 0.0001 # learning rate
etay = 0.0001 # learning rate
H = 20000 # Horizon
trails_num = 100
episode_num = 10000

episode_num_forpath1 = 4000 # REINFORCE
episode_num_forpath = 4000 # MVP
episode_num_forpath2 = 4000 # Tamar

etar = 0.7 # REINFORCE
eta = 0.09 # MVP
alpha = 0.002 # Tamar
alpharcpg = 0.01 # RCPG
alpharcpg2 = 0.07 # SGD

lbd = 0.3
lbd1 = 0.1 # RCPG
lbd2 = 0.1 # SGD

IfControl = True

environment = "Portfolio" # Portfolio, American_Option

IfHist = False # True, False
#################################################

if environment == "Portfolio":
    env = Portfolio()
    policy = env.binary_policy # policy(theta,s)
if environment == "American_Option":
    env = American_Option()
    policy = env.binary_policy # policy(theta,s)
if environment == "Optimal_Stopping":
    env = Optimal_Stopping()
    policy = env.binary_policy # policy(theta,s)

if __name__ == '__main__':
    all_REINFORCE_return = []
    all_MVP_return = []
    all_Tamar_return = []
    all_RCPG_return = []
    all_SGD_return = []

    # print "trail#: "

    # p.start(trails_num)
    for i in xrange(trails_num):
        # p.update(i+1)
        REINFORCE_savename = savename = "./" + environment + "_policy/REINFORCE1/_" + str(etar) + "_" + str(episode_num_forpath1) +  "_/REINFORCE_value_" + str(i) + ".txt"
        MVP_savename = "./" + environment + "_policy/MVP/_" + "lbd" + str(lbd) + "_" + str(eta) + "_" + str(episode_num_forpath) + str(IfControl) + "_/MVP_value_" + str(i) + ".txt"
        Tamar_savename = "./" + environment + "_policy/Tamar/_" + str(alpha) + "_" + str(episode_num_forpath2) +  "_/Tamar_value_" + str(i) + ".txt"
        RCPG_savename = "./" + environment + "_policy/RCPG/_" + "lbd" + str(lbd1) + "_" + str(alpharcpg) + "_" + str(episode_num_forpath) + str(IfControl) + "_/RCPG_value_" + str(i) + ".txt"
        SGD_savename = "./" + environment + "_policy/SGD/_" + "lbd" + str(lbd2) + "_" + str(alpharcpg2) + "_" + str(episode_num_forpath) + str(IfControl) + "_/SGD_value_" + str(i) + ".txt"

        REINFORCE_value = np.loadtxt(REINFORCE_savename)
        MVP_value = np.loadtxt(MVP_savename)
        Tamar_value = np.loadtxt(Tamar_savename)
        RCPG_value = np.loadtxt(RCPG_savename)
        SGD_value = np.loadtxt(SGD_savename)

        bd = 14

        if REINFORCE_value >= bd:
            all_REINFORCE_return.append(REINFORCE_value)
        # print "MVP: "
        if MVP_value >= bd:
            all_MVP_return.append(MVP_value)
        # print "Tamar: "
        if Tamar_value >= bd:
            all_Tamar_return.append(Tamar_value)
        if RCPG_value >= bd:
            all_RCPG_return.append(RCPG_value)
        if SGD_value >= bd:
            all_SGD_return.append(SGD_value)
    # p.finish()

    all_REINFORCE_return.sort()
    all_MVP_return.sort()
    all_Tamar_return.sort()
    all_RCPG_return.sort()
    all_SGD_return.sort()

    # print all_REINFORCE_return
    # print all_MVP_return

    # print all_Tamar_return

    nb = 0

    all_REINFORCE_return = all_REINFORCE_return[nb:]
    all_MVP_return = all_MVP_return[nb:]
    all_Tamar_return = all_Tamar_return[nb:]
    all_RCPG_return = all_RCPG_return[nb:]
    all_SGD_return = all_SGD_return[nb:]

    REINFORCE_mean = np.mean(all_REINFORCE_return)
    MVP_mean = np.mean(all_MVP_return)
    Tamar_mean = np.mean(all_Tamar_return)
    RCPG_mean = np.mean(all_RCPG_return)
    SGD_mean = np.mean(all_SGD_return)

    REINFORCE_std = np.std(all_REINFORCE_return)
    MVP_std = np.std(all_MVP_return)
    Tamar_std = np.std(all_Tamar_return)
    RCPG_std = np.std(all_RCPG_return)
    SGD_std = np.std(all_SGD_return)


    print "MVP: ", MVP_mean, MVP_std
    print "PG: ", REINFORCE_mean, REINFORCE_std
    print "Tamar: ", Tamar_mean, Tamar_std
    print "SGA: ", SGD_mean, SGD_std
    print "RCPG: ", RCPG_mean, RCPG_std
    

    REINFORCE_x = np.linspace(REINFORCE_mean - 3 * REINFORCE_std,REINFORCE_mean + 3 * REINFORCE_std,10000)
    MVP_x = np.linspace(MVP_mean - 3 * MVP_std,MVP_mean + 3 * MVP_std,10000)
    Tamar_x = np.linspace(Tamar_mean - 3 * Tamar_std,Tamar_mean + 3 * Tamar_std,10000)
    RCPG_x = np.linspace(RCPG_mean - 3 * RCPG_std,RCPG_mean + 3 * RCPG_std,10000)
    SGD_x = np.linspace(SGD_mean - 3 * SGD_std,SGD_mean + 3 * SGD_std,10000)


    mv1 = [4500]
    mv2 = [5500]
    mv3 = [5500]
    mv4 = [5000]
    mv5 = [5000]
    msz = 20
    mew = 2.0

    fig = plt.figure(figsize=(12,9))
    plt.ylim(0,1.3)
    # plt.xlim(24.5,31.5)
    plt.plot(MVP_x, norm.pdf(MVP_x, loc=MVP_mean, scale=MVP_std), '#e41a1c',linewidth=5, label='MVP',linestyle="solid",marker="o",markevery=mv1,markersize=msz,markeredgecolor="k",markeredgewidth=mew)
    plt.plot(SGD_x, norm.pdf(SGD_x, loc=SGD_mean, scale=SGD_std), '#999999',linewidth=5, label='SGD',linestyle="--",marker="d",markevery=mv5,markersize=msz,markeredgecolor="k",markeredgewidth=mew,dashes=(1,0.5))
    plt.plot(RCPG_x, norm.pdf(RCPG_x, loc=RCPG_mean, scale=RCPG_std), '#984ea3',linewidth=5, label='RCPG',linestyle=":",marker="X",markevery=mv2,markersize=msz,markeredgecolor="k",markeredgewidth=mew)
    plt.plot(Tamar_x, norm.pdf(Tamar_x, loc=Tamar_mean, scale=Tamar_std), '#4daf4a',linewidth=5, label='Tamar',linestyle="--",marker=">",markevery=mv4,markersize=msz,markeredgecolor="k",markeredgewidth=mew)
    plt.plot(REINFORCE_x, norm.pdf(REINFORCE_x, loc=REINFORCE_mean, scale=REINFORCE_std), '#377eb8',linewidth=5, label='PG',linestyle="-.",marker="s",markevery=mv3,markersize=msz,markeredgecolor="k",markeredgewidth=mew)
    leg = plt.legend(loc=[0,0.55],frameon=False,framealpha=1.0,edgecolor='k',ncol=1)
    leg.get_frame().set_linewidth(1.0)
    plt.xlabel(r'Accumulated Reward')
    plt.ylabel('Probability Density Function (PDF)')
    sns.despine()
    fig.tight_layout()
    plt.show()
    fig.savefig("plots/_" + str(eta) + "_" + str(episode_num_forpath) +"_.pdf",bbox_inches='tight')
    print "Succeed!"
