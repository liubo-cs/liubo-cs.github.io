import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA

import matplotlib.pyplot as plt

from util import *
from Portfolio import *
from American_Option import *
from Optimal_Stopping import *
from cluster_Prob_Dist_Test import *

np.set_printoptions(precision=3,suppress=True)
#################################################
# Hyperparameters
e = 0.1 # e greedy policy
H = 20000 # Horizon
trails_num = 1
episode_num = 4000

IfPrint = False # True, False

environment = "Portfolio" # Portfolio, American_Option, Optimal_Stopping
#################################################

if environment == "Portfolio":
    env = Portfolio()
    policy = env.ep_binary_policy # policy(theta,s)
    alpha = 0.001 # learning rate
    beta = 0.001 # learning rate

if environment == "American_Option":
    env = American_Option()
    policy = env.binary_policy # policy(theta,s)
    alpha = 0.00025 # learning rate
    beta = 0.00025 # learning rate

if environment == "Optimal_Stopping":
    env = Optimal_Stopping()
    policy = env.binary_policy # policy(theta,s)
    alpha = 0.001 # learning rate
    beta = 0.001 # learning rate


def choose_action(act_dist):
    action_choices = len(act_dist)
    action = np.random.choice(action_choices,p=act_dist)
    return action

b = 20
lbd = 0.1

def Portfolio_main():
    para = sys.argv
    i = int(para[1])
    stepsize = float(para[2])
    alpha = stepsize
    beta = stepsize

    total_r = []
    s = env.reset()
    feature = env.phi(s)
    theta = feature * 0
    Jhat = 25
    Vhat = 10
    for episode in xrange(episode_num):
        # if episode % 10 == 0:
        if episode % 10 == 0 and episode > 0 and IfPrint:
            print "episode: ", episode
            print total_reward
        s = env.reset()
        IfEnd = False
        total_reward = 0
        grad_logpolicy = theta * 0
        while not IfEnd:
            # feature = env.phi(s)
            act_dist = policy(theta,s)
            a = choose_action(act_dist)
            s, r, IfEnd = env.next_step(s,a)
            total_reward += r
            grad_logpolicy += env.ep_grad_log_policy(theta,s,a,act_dist)
        total_reward += env.ini_money
        total_reward = np.log(total_reward)
        total_r.append(total_reward)
        control = np.mean(total_r)
        control = 28
        beta1 = max(beta / (episode + 1), 0.0001)
        alpha1 = max(alpha / (episode + 1) ** 0.6, 0.0001)
        tempep = 0
        temp1 = total_reward - control
        temp2 = Jhat * total_reward ** 2 - 2 * total_reward * Jhat ** 2 + tempep
        temp3 = 2 * Vhat + tempep
        theta += beta1 * (temp1 - temp2 / temp3) * grad_logpolicy / Vhat ** 2
        # theta += theta + beta1 * (temp1 - lbd * (Vhat - b) ** 2 * (total_reward ** 2 - 2 * total_reward * Jhat)) * grad_logpolicy
        Jhat1 = Jhat +  alpha1 * (total_reward - Jhat)
        Vhat1 = Vhat + alpha1 * (total_reward ** 2 - Jhat ** 2 - Vhat)
        Jhat = Jhat1 + 0.0
        Vhat = Vhat1 + 0.0
    savename = "./" + environment + "_policy/Tamar/_" + str(alpha) + "_" + str(episode_num) +  "_/Tamar_theta_" + str(i) + ".txt"
    ensure_dir(savename)
    np.savetxt(savename,theta)
    if IfPrint:
        plt.figure(1)
        plt.plot(total_r,'g-',label = 'Tamar')
        plt.show()

    value = Portfolio_run_once(theta)
    savevalue = "./" + environment + "_policy/Tamar/_" + str(alpha) + "_" + str(episode_num) +  "_/Tamar_value_" + str(i) + ".txt"
    np.savetxt(savevalue,np.array(value).reshape(1,))


def American_Option_main():
    para = sys.argv
    i = int(para[1])
    stepsize = float(para[2])
    alpha = stepsize
    beta = stepsize

    total_r = []
    s = env.reset()
    feature = env.phi(s)
    theta = feature * 0
    Jhat = -1.5
    Vhat = 0.1
    for episode in xrange(episode_num):
        # if episode % 10 == 0:
        if episode % 10 == 0 and episode > 0 and IfPrint:
            print "episode: ", episode
            print total_reward
        s = env.reset()
        IfEnd = False
        total_reward = 0
        grad_logpolicy = theta * 0
        while not IfEnd:
            # feature = env.phi(s)
            act_dist = policy(theta,s)
            a = choose_action(act_dist)
            s, r, IfEnd = env.next_step(s,a)
            grad_logpolicy += env.grad_log_policy(theta,s,a,act_dist)
            total_reward += r
        total_r.append(total_reward)
        control = np.mean(total_r)
        beta1 = max(beta / (episode + 1), 0.000001)
        alpha1 = max(alpha / (episode + 1) ** 0.6, 0.000001)
        tempep = 1e-8
        temp1 = total_reward - control
        temp2 = Jhat * total_reward ** 2 - 2 * total_reward * Jhat ** 2 + tempep
        temp3 = 2 * Vhat + tempep
        # theta += beta1 * (temp1 - temp2 / temp3) * grad_logpolicy / Vhat ** 2
        theta += theta + beta1 * (temp1 - lbd * (Vhat - b) ** 2 * (total_reward ** 2 - 2 * total_reward * Jhat)) * grad_logpolicy
        Jhat1 = Jhat +  alpha1 * (total_reward - Jhat)
        Vhat1 = Vhat + alpha1 * (total_reward ** 2 - Jhat ** 2 - Vhat)
        Jhat = Jhat1 + 0.0
        Vhat = Vhat1 + 0.0
    savename = "./" + environment + "_policy/Tamar/_" + str(alpha) + "_" + str(episode_num) +  "_/Tamar_theta_" + str(i) + ".txt"
    ensure_dir(savename)
    np.savetxt(savename,theta)
    if IfPrint:
        plt.figure(1)
        plt.plot(total_r,'g-',label = 'Tamar')
        plt.show()

    value = American_Option_run_once(theta)
    savevalue = "./" + environment + "_policy/Tamar/_" + str(alpha) + "_" + str(episode_num) +  "_/Tamar_value_" + str(i) + ".txt"
    np.savetxt(savevalue,np.array(value).reshape(1,))

if environment == "Portfolio":
    main = Portfolio_main
if environment == "American_Option" or environment == "Optimal_Stopping":
    main = American_Option_main

if __name__ == '__main__':
    main()
    print "Succeed!"
