submit = open("submit.sh", "wb")
sub_wr_line = "#!/bin/bash" + "\n"
submit.writelines(sub_wr_line)
sub_wr_line = "# chmod 0764" + "\n"
submit.writelines(sub_wr_line)

stepsize = 0.01

num = 100
j = 0

    # REINFORCE
for i in xrange(num):
    j += 1
    name = "step" + str(j) + ".sh"
    output = open("dotshes/" + name, "wb")
    wr_line = "#!/bin/bash" + "\n"
    output.writelines(wr_line)
    wr_line = "#" + "\n"
    output.writelines(wr_line)
    wr_line = "#SBATCH --job-name=mvp" + "\n"
    output.writelines(wr_line)
    wr_line = "#SBATCH --output=outputs/temp" + str(j) + ".out " + "\n"
    output.writelines(wr_line)
    wr_line = "#SBATCH --partition=defq" + "\n"
    output.writelines(wr_line)
    wr_line = "#SBATCH --mem-per-cpu=1000" + "\n"
    output.writelines(wr_line)
    wr_line = "python cluster_REINFORCE.py " + str(i) + " " + str(stepsize) + "\n"
    output.writelines(wr_line)
    output.close()

    sub_wr_line = "sbatch " + name + "\n"
    submit.writelines(sub_wr_line)

    # MVP
for i in xrange(num * 0):
    j += 1
    name = "step" + str(j) + ".sh"
    output = open("dotshes/" + name, "wb")
    wr_line = "#!/bin/bash" + "\n"
    output.writelines(wr_line)
    wr_line = "#" + "\n"
    output.writelines(wr_line)
    wr_line = "#SBATCH --job-name=mvp" + "\n"
    output.writelines(wr_line)
    wr_line = "#SBATCH --output=outputs/temp" + str(j) + ".out " + "\n"
    output.writelines(wr_line)
    wr_line = "#SBATCH --partition=defq" + "\n"
    output.writelines(wr_line)
    wr_line = "#SBATCH --mem-per-cpu=1000" + "\n"
    output.writelines(wr_line)
    wr_line = "python cluster_MVP.py " + str(i) + " " + str(stepsize) + "\n"
    output.writelines(wr_line)
    output.close()

    sub_wr_line = "sbatch " + name + "\n"
    submit.writelines(sub_wr_line)

    # Tamar
for i in xrange(num * 0):
    j += 1
    name = "step" + str(j) + ".sh"
    output = open("dotshes/" + name, "wb")
    wr_line = "#!/bin/bash" + "\n"
    output.writelines(wr_line)
    wr_line = "#" + "\n"
    output.writelines(wr_line)
    wr_line = "#SBATCH --job-name=mvp" + "\n"
    output.writelines(wr_line)
    wr_line = "#SBATCH --output=outputs/temp" + str(j) + ".out " + "\n"
    output.writelines(wr_line)
    wr_line = "#SBATCH --partition=defq" + "\n"
    output.writelines(wr_line)
    wr_line = "#SBATCH --mem-per-cpu=1000" + "\n"
    output.writelines(wr_line)
    wr_line = "python cluster_Tamar.py " + str(i) + " " + str(stepsize) + "\n"
    output.writelines(wr_line)
    output.close()

    sub_wr_line = "sbatch " + name + "\n"
    submit.writelines(sub_wr_line)

submit.close()

