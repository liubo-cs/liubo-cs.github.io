import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA
import seaborn as sns
from scipy.stats import norm
# import progressbar
# p = progressbar.ProgressBar()

import matplotlib.pyplot as plt

from util import *
from Portfolio import *
from American_Option import *
from Optimal_Stopping import *

np.set_printoptions(precision=3,suppress=True)
#################################################
# Hyperparameters
e = 0.1 # e greedy policy
eta = 0.0001 # learning rate
etay = 0.0001 # learning rate
H = 20000 # Horizon
trails_num = 30
episode_num = 10000

episode_num_forpath1 = 10000 # REINFORCE
episode_num_forpath = 10000 # MVP
episode_num_forpath2 = 10000 # Tamar

etar = 0.05 # REINFORCE
eta = 0.05 # MVP
alpha = 0.01 # Tamar

# all_eta = [0.0001,0.00025,0.0005,0.001,0.0025,0.005,0.01,0.025,0.05]
all_eta = [0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1]

environment = "American_Option" # Portfolio, American_Option

IfHist = False # True, False
#################################################

if environment == "Portfolio":
    env = Portfolio()
    policy = env.binary_policy # policy(theta,s)
if environment == "American_Option":
    env = American_Option()
    policy = env.binary_policy # policy(theta,s)
if environment == "Optimal_Stopping":
    env = Optimal_Stopping()
    policy = env.binary_policy # policy(theta,s)

if __name__ == '__main__':
    var = []
    mean = []
    mv = []

    REINFORCEvar = []
    REINFORCEmean = []
    REINFORCEmv = []

    Tamarvar = []
    Tamarmean = []
    Tamarmv = []
    for eta in all_eta:
        all_REINFORCE_return = []
        all_MVP_return = []
        all_Tamar_return = []

        for i in xrange(trails_num):
            # p.update(i+1)
            REINFORCE_savename = savename = "./" + environment + "_policy/REINFORCE/_" + str(eta) + "_" + str(episode_num_forpath1) +  "_/REINFORCE_value_" + str(i) + ".txt"
            MVP_savename = "./" + environment + "_policy/MVP/_" + str(eta) + "_" + str(episode_num_forpath) +  "_/MVP_value_" + str(i) + ".txt"
            Tamar_savename = "./" + environment + "_policy/Tamar/_" + str(eta) + "_" + str(episode_num_forpath2) +  "_/Tamar_value_" + str(i) + ".txt"

            REINFORCE_value = np.loadtxt(REINFORCE_savename)
            MVP_value = np.loadtxt(MVP_savename)
            Tamar_value = np.loadtxt(Tamar_savename)

            # print "REINFORCE: "
            all_REINFORCE_return.append(REINFORCE_value)
            # print "MVP: "
            all_MVP_return.append(MVP_value)
            # print "Tamar: "
            all_Tamar_return.append(Tamar_value)

        all_MVP_return.sort()
        all_MVP_return = all_MVP_return[:]
        tempvar = np.std(all_MVP_return)
        tempmean = np.mean(all_MVP_return)
        var.append(tempvar)
        mean.append(tempmean)
        mv.append(tempmean - 5 * tempvar)

        all_REINFORCE_return.sort()
        all_REINFORCE_return = all_REINFORCE_return[:]
        REINFORCEtempvar = np.std(all_REINFORCE_return)
        REINFORCEtempmean = np.mean(all_REINFORCE_return)
        REINFORCEvar.append(REINFORCEtempvar)
        REINFORCEmean.append(REINFORCEtempmean)
        REINFORCEmv.append(REINFORCEtempmean - 5 * REINFORCEtempvar)

        all_Tamar_return.sort()
        all_Tamar_return = all_Tamar_return[:]
        Tamartempvar = np.std(all_Tamar_return)
        Tamartempmean = np.mean(all_Tamar_return)
        Tamarvar.append(Tamartempvar)
        Tamarmean.append(Tamartempmean)
        Tamarmv.append(Tamartempmean - 5 * Tamartempvar)
    
    print all_eta
    print "Mean:"
    print mean
    print REINFORCEmean
    print Tamarmean
    print "Std:"
    print var
    print REINFORCEvar
    print Tamarvar