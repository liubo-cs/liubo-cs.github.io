import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA

from util import *


#################################
# Parameters

T = 50 # length of episode
ini_money = 1000000.0 # initial money
N = 4 # length of maturity period
r_l = 1.001 - 1
r_nl_h = 2 - 1 # r_nl^high
r_nl_l = 1.1 - 1 # r_nl^low
p_switch = 0.1
alpha = 0.2 # fixed investing fraction
p_risk = 0.05
epsilon = 0.1

n = 2 # n order base
#################################


class Portfolio(object):
    def __init__(self):
        self.timestep = 1
        self.state_space = N + 2
        self.ini_money = ini_money

    def norm(self,s):
        s1 = s.copy()
        summ = s[:-1].sum()
        s1[:-1] /= summ
        return s1

    def reset(self):
        self.timestep = 1
        s = np.zeros(self.state_space)
        s[0] += ini_money # cash
        s[-1] = np.random.randint(2) # 0 - r_nl^low, 1-r_nl^high
        return s

    # return reward, state, if_done
    def next_step(self,s,a): # a = 1, invest
        IfEnd = False
        if self.timestep >= T:
            IfEnd = True
        self.timestep += 1

        if s[-1] == 0:
            r_nl = r_nl_l * 1.0
        else:
            r_nl = r_nl_h * 1.0

        s1 = s.copy()

        risk = np.random.choice(2,p=[p_risk, 1 - p_risk]) # risk = 0, loose money
        # interest
        # reward = s[0] * (r_l) + (s[1:-1] * (r_nl)).sum()
        # s1[0] *= (1 + r_l)
        # s1[1:-1] *= (1 + r_nl)
        # assets transfer
        s1[1:-1] *= 0
        s1[0] += s[1] * risk
        s1[1:-2] = s[2:-1].copy()

        all_money = s1[:-1].sum()
        cash_ratio = s1[0] / all_money

        if cash_ratio >= alpha:
            # invest alpha * cash
            s1[-2] = a * alpha * all_money
            s1[0] -= a * alpha * all_money

        s1[0] *= (1 + r_l)
        s1[1:-1] *= (1 + r_nl)

        reward = s1[:-1].sum() - s[:-1].sum()

        # nl interest switch
        rand_temp = np.random.choice(2,p=[0.9, 0.1])
        s1[-1] = np.fabs(rand_temp - s[-1])


        return s1, reward, IfEnd

    def phi(self,s): # Fourier Basis
        s1 = self.norm(s)
        return s1
        d = s.shape[0]
        y = np.zeros((n + 1) ** d)
        c = np.zeros(d)
        for i in xrange((n + 1) ** d):
            temp = i + 0
            for j in xrange(d):
                c[j] = temp % (n + 1)
                temp -= c[j]
                temp /= (n + 1)
            c_dot_s = np.dot(c,s1)
            y[i] = math.cos(math.pi * c_dot_s)
        return y


    def binary_policy(self,theta,s): # binary policy for Portfolio domain
        # ep = 0.05
        feature = self.phi(s)
        theta_dot_x = np.dot(theta,feature)
        theta_dot_x = max(theta_dot_x,-200)
        # prob = ep + (1 - 2 * ep) / (1 + np.exp(theta_dot_x)) # prob for investing
        prob = 1 / (1 + np.exp(-1 * theta_dot_x)) # prob for investing (a = 1)

        # act_dist = np.zeros(2)
        # act_dist[0] = 1 - prob
        # act_dist[1] = prob
        return [1 - prob, prob]

    def ep_binary_policy(self,theta,s): # binary policy for Portfolio domain
        # ep = 0.05
        feature = self.phi(s)
        theta_dot_x = np.dot(theta,feature)
        theta_dot_x = max(theta_dot_x,-200)
        # prob = ep + (1 - 2 * ep) / (1 + np.exp(theta_dot_x)) # prob for investing
        prob = epsilon + (1- 2 * epsilon) / (1 + np.exp(-1 * theta_dot_x)) # prob for investing (a = 1)

        # act_dist = np.zeros(2)
        # act_dist[0] = 1 - prob
        # act_dist[1] = prob
        return [1 - prob, prob]

    def grad_log_policy(self,theta,s,a,act_dist):
        feature = self.phi(s)
        # theta_dot_x = np.dot(theta,feature)
        # if a == 1:
        #     exp_theta_dot_x = np.exp(-1 * theta_dot_x)
        #     grad = feature * exp_theta_dot_x / (1 + exp_theta_dot_x)
        # else:
        #     exp_theta_dot_x = np.exp(theta_dot_x)
        #     grad = -1 * feature * exp_theta_dot_x / (1 + exp_theta_dot_x)

        if a == 1:
            grad = feature * act_dist[0]
        else:
            grad = -1 * feature * act_dist[1]
        return grad


    def ep_grad_log_policy(self,theta,s,a,act_dist):
        feature = self.phi(s)
        # theta_dot_x = np.dot(theta,feature)
        # if a == 1:
        #     exp_theta_dot_x = np.exp(-1 * theta_dot_x)
        #     grad = feature * exp_theta_dot_x / (1 + exp_theta_dot_x)
        # else:
        #     exp_theta_dot_x = np.exp(theta_dot_x)
        #     grad = -1 * feature * exp_theta_dot_x / (1 + exp_theta_dot_x)


        feature = self.phi(s)
        theta_dot_x = np.dot(theta,feature)
        theta_dot_x = max(theta_dot_x,-200)

        if a == 1:
            grad = feature *  np.exp(-1 * theta_dot_x) * (1 - 2 * epsilon) / ((1 + np.exp(-1 * theta_dot_x)) ** 2 * act_dist[1])
        else:
            grad = -1 * feature *  np.exp(theta_dot_x) * (1 - 2 * epsilon) / ((1 + np.exp(theta_dot_x)) ** 2 * act_dist[0])
        return grad
