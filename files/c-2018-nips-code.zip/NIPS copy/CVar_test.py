import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA
import seaborn as sns

from scipy.stats import norm

import matplotlib.pyplot as plt

from util import *
from Portfolio import *

env = Portfolio()
policy = env.binary_policy # policy(theta,s)

np.set_printoptions(precision=3,suppress=True)
#################################################
# Hyperparameters
e = 0.1 # e greedy policy
H = 20000 # Horizon
trails_num = 30
episode_num = 1000

#################################################


def choose_action(act_dist):
    action_choices = len(act_dist)
    action = np.random.choice(action_choices,p=act_dist)
    return action

def run_once(theta):

    # REINFORCE_savename = "./Portfolio_policy/REINFORCE/REINFORCE_theta_" + str(i) + ".txt"
    # MVP_savename = "./Portfolio_policy/MVP/MVP_theta_" + str(i) + ".txt"
    # REINFORCE_theta = np.loadtxt(REINFORCE_savename)
    # MVP_theta = np.loadtxt(MVP_savename)

    temp_return = []
    MVP_return = []

    for episode in xrange(episode_num):
        # if episode % 10 == 0:
        # if episode % 10 == 0:
        #     print "episode: ", episode
        s = env.reset()
        IfEnd = False
        total_reward = 0
        grad_logpolicy = theta * 0
        while not IfEnd:
            # feature = env.phi(s)
            act_dist = policy(theta,s)
            a = choose_action(act_dist)
            s, r, IfEnd = env.next_step(s,a)
            total_reward += r
        total_reward = np.log(total_reward)
        temp_return.append(total_reward)
        return temp_return


    # for episode in xrange(episode_num):
    #     # if episode % 10 == 0:
    #     # if episode % 10 == 0:
    #     #     print "episode: ", episode
    #     s = env.reset()
    #     IfEnd = False
    #     total_reward = 0
    #     grad_logpolicy = MVP_theta * 0
    #     while not IfEnd:
    #         # feature = env.phi(s)
    #         act_dist = policy(MVP_theta,s)
    #         a = choose_action(act_dist)
    #         s, r, IfEnd = env.next_step(s,a)
    #         total_reward += r
    #     total_reward = np.log(total_reward)
    #     MVP_return.append(total_reward)
    # return [REINFORCE_return,MVP_return]

    # plt.figure(1)
    # sns.distplot(REINFORCE_return,color = 'b',hist=False)
    # sns.distplot(MVP_return,color = 'r',hist=False)
    # plt.show()

if __name__ == '__main__':
    all_REINFORCE_return = []
    all_MVP_return = []
    all_Tamar_return = []
    for i in xrange(trails_num):

        REINFORCE_savename = "./Portfolio_policy/REINFORCE/REINFORCE_theta_" + str(i) + ".txt"
        MVP_savename = "./Portfolio_policy/MVP/MVP_theta_" + str(i) + ".txt"
        Tamar_savename = "./Portfolio_policy/Tamar/Tamar_theta_" + str(i) + ".txt"
        REINFORCE_theta = np.loadtxt(REINFORCE_savename)
        MVP_theta = np.loadtxt(MVP_savename)
        Tamar_theta = np.loadtxt(MVP_savename)

        print "trail#: ",i

        all_REINFORCE_return.extend(run_once(REINFORCE_theta))
        all_MVP_return.extend(run_once(MVP_theta))
        all_Tamar_return.extend(run_once(Tamar_theta))

    REINFORCE_mu, REINFORCE_sig = norm.fit(all_REINFORCE_return)
    MVP_mu, MVP_sig = norm.fit(all_MVP_return)
    Tamar_mu, Tamar_sig = norm.fit(all_Tamar_return)

    alphas = np.linspace(0.001,1, 500)

    plt.figure(1)
    plt.plot(alphas, CVaR_F, 'b',linewidth=4, label='PGSA',linestyle="dotted")
    plt.plot(alphas, CVaR_B, 'r',linewidth=4, label='MPPG',linestyle="solid")
    plt.plot(alphas, CVaR_D, 'g',linewidth=4, label='RCPG',linestyle="dashed")
    sns.distplot(all_REINFORCE_return,color = 'b',hist=False,label = 'REINFORCE')
    sns.distplot(all_MVP_return,color = 'r',hist=False,label = 'MVP')
    sns.distplot(all_Tamar_return,color = 'g',hist=False,label = 'Tamar')
    plt.show()
