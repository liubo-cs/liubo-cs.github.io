submit = open("submit.sh", "wb")
sub_wr_line = "#!/bin/bash" + "\n"
submit.writelines(sub_wr_line)
sub_wr_line = "# chmod 0764" + "\n"
submit.writelines(sub_wr_line)

# all_stepsize = [0.001,0.003,0.01,0.03,0.06,0.1]
# all_stepsize = [0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1]
# all_stepsize = [0.06,0.07,0.08,0.09,0.1]
# all_stepsize = [0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6,0.65,0.7,0.75]
# all_stepsize = [0.0004,0.0008,0.0012,0.0016,0.002]
all_stepsize = [0.001,0.002,0.003,0.004,0.005,0.006,0.007,0.008,0.009]
# all_stepsize = [0.0001,0.0002,0.0003,0.0004,0.0005,0.0006,0.0007]
# all_lbd = [0.1,1,2,3,4,5]
all_lbd = [0.1]
# all_lbd = [0.1,0.2,0.3,0.4,0.5]

num = 100
j = 0

IfControl = False

for lbd in all_lbd:
    for stepsize in all_stepsize:
        for i in xrange(num):
            j += 1
            name = "step" + str(j) + ".sh"
            output = open("dotshes/" + name, "wb")
            wr_line = "#!/bin/bash" + "\n"
            output.writelines(wr_line)
            wr_line = "#" + "\n"
            output.writelines(wr_line)
            wr_line = "#SBATCH --job-name=mvp" + "\n"
            output.writelines(wr_line)
            wr_line = "#SBATCH --output=outputs/temp" + str(j) + ".out " + "\n"
            output.writelines(wr_line)
            wr_line = "#SBATCH --partition=defq" + "\n"
            output.writelines(wr_line)
            wr_line = "#SBATCH --mem-per-cpu=1000" + "\n"
            output.writelines(wr_line)
            wr_line = "python cluster_Tamar.py " + str(i) + " " + str(stepsize) + " " + str(lbd) + " " + str(IfControl) + "\n"
            output.writelines(wr_line)
            output.close()

            sub_wr_line = "sbatch " + name + "\n"
            submit.writelines(sub_wr_line)

submit.close()

