import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA
import seaborn as sns
from scipy.stats import norm
# import progressbar
# p = progressbar.ProgressBar()

import matplotlib.pyplot as plt

from util import *
from Portfolio import *
from American_Option import *
from Optimal_Stopping import *

# np.set_printoptions(precision=3,suppress=True)
#################################################
# Hyperparameters
e = 0.1 # e greedy policy
eta = 0.0001 # learning rate
etay = 0.0001 # learning rate
H = 20000 # Horizon
trails_num = 100
episode_num = 10000

episode_num_forpath1 = 4000 # REINFORCE
episode_num_forpath = 4000 # MVP
episode_num_forpath2 = 4000 # Tamar

etar = 0.05 # REINFORCE
eta = 0.05 # MVP
alpha = 0.01 # Tamar

# all_stepsize = [0.001,0.003,0.01,0.03,0.06,0.1]
# all_stepsize = [0.001,0.002,0.003,0.004,0.005,0.006,0.007,0.008,0.009]
# all_stepsize = [0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1]
# all_stepsize = [0.05,0.06,0.07,0.08,0.09,0.1]
# all_stepsize = [0.01,0.02,0.03,0.04,0.05]
# all_stepsize = [0.06,0.07,0.08,0.09,0.1]
# all_stepsize = [0.01,0.02,0.03,0.04,0.05,0.06]
all_stepsize = [0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6,0.65,0.7,0.75]
# all_stepsize = [0.06,0.07,0.08,0.09,0.1]
# all_stepsize = [0.001,0.002,0.003,0.004,0.005,0.006]
# all_stepsize = [0.0004,0.0008,0.0012,0.0016,0.002]
# all_stepsize = [0.001,0.002,0.003,0.004,0.005,0.006,0.007,0.008,0.009]
# all_stepsize = [0.0001,0.0002,0.0003,0.0004,0.0005,0.0006,0.0007,0.0008,0.0009]
# all_stepsize = [0.5,0.55,0.6,0.65,0.7,0.75]
# all_lbd = [0.1,1.0,2.0,3.0,4.0,5.0]
all_lbd = [0.1]
# all_lbd = [0.1,0.2,0.3,0.4,0.5]

environment = "Portfolio" # Portfolio, American_Option

IfControl = True

IfHist = False # True, False
#################################################

if environment == "Portfolio":
    env = Portfolio()
    policy = env.binary_policy # policy(theta,s)
if environment == "American_Option":
    env = American_Option()
    policy = env.binary_policy # policy(theta,s)
if environment == "Optimal_Stopping":
    env = Optimal_Stopping()
    policy = env.binary_policy # policy(theta,s)

if __name__ == '__main__':
    for lbd in all_lbd:
        print lbd
        var = []
        mean = []
        mv = []
        for eta in all_stepsize:
            all_REINFORCE_return = []
            all_MVP_return = []
            all_Tamar_return = []

            for i in xrange(trails_num):
                # p.update(i+1)
                MVP_savename = savename = "./" + environment + "_policy/REINFORCE1/_" + str(eta) + "_" + str(episode_num_forpath1) +  "_/REINFORCE_value_" + str(i) + ".txt"
                # MVP_savename = "./" + environment + "_policy/MVP/_" + "lbd" + str(lbd) + "_" + str(eta) + "_" + str(episode_num_forpath) + str(IfControl) + "_/MVP_value_" + str(i) + ".txt"
                # MVP_savename = "./" + environment + "_policy/Tamar/_" + str(eta) + "_" + str(episode_num_forpath2) +  "_/Tamar_value_" + str(i) + ".txt"
                # MVP_savename = "./" + environment + "_policy/RCPG/_" + "lbd" + str(lbd) + "_" + str(eta) + "_" + str(episode_num_forpath) + str(IfControl) + "_/RCPG_value_" + str(i) + ".txt"
                # MVP_savename = "./" + environment + "_policy/SGD/_" + "lbd" + str(lbd) + "_" + str(eta) + "_" + str(episode_num_forpath) + str(IfControl) + "_/SGD_value_" + str(i) + ".txt"
                
                # REINFORCE_value = np.loadtxt(REINFORCE_savename)
                MVP_value = np.loadtxt(MVP_savename)
                # Tamar_value = np.loadtxt(Tamar_savename)

                # print "REINFORCE: "
                # all_REINFORCE_return.append(REINFORCE_value)
                # print "MVP: "
                bd = 14
                if MVP_value >= bd:
                    all_MVP_return.append(MVP_value)
                # print "Tamar: "
                # all_Tamar_return.append(Tamar_value)

            nb = 0
            all_MVP_return.sort()
            # print all_MVP_return
            all_MVP_return = all_MVP_return[nb:]
            tempvar = np.std(all_MVP_return)
            tempmean = np.mean(all_MVP_return)
            var.append(tempvar)
            mean.append(tempmean)
            mv.append(tempmean - 5 * tempvar)

    
        print all_stepsize
        print "Mean:"
        print mean
        print "Std:"
        print var