import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA
import os


#################################################
# Hyperparameters


#################################################


def ensure_dir(name):
    d = os.path.dirname(name)
    if not os.path.exists(d):
        os.makedirs(d)