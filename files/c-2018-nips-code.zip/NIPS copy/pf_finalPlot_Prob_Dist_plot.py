import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA
import seaborn as sns
from scipy.stats import norm
# import progressbar
# p = progressbar.ProgressBar()

import matplotlib.pyplot as plt

from util import *
from Portfolio import *
from American_Option import *
from Optimal_Stopping import *

sns.set_context("poster",font_scale=1.9)
sns.set_style("ticks")

np.set_printoptions(precision=3,suppress=True)
#################################################
# Hyperparameters
e = 0.1 # e greedy policy
eta = 0.0001 # learning rate
etay = 0.0001 # learning rate
H = 20000 # Horizon
trails_num = 100
episode_num = 10000

episode_num_forpath1 = 4000 # REINFORCE
episode_num_forpath = 4000 # MVP
episode_num_forpath2 = 4000 # Tamar

etar = 0.7 # REINFORCE
eta = 0.09 # MVP
alpha = 0.002 # Tamar
alpharcpg = 0.01 # RCPG
alpharcpg2 = 0.07 # SGD

lbd = 0.3
lbd1 = 0.1 # RCPG
lbd2 = 0.1 # SGD

IfControl = True

environment = "Portfolio" # Portfolio, American_Option

IfHist = False # True, False
#################################################

if environment == "Portfolio":
    env = Portfolio()
    policy = env.binary_policy # policy(theta,s)
if environment == "American_Option":
    env = American_Option()
    policy = env.binary_policy # policy(theta,s)
if environment == "Optimal_Stopping":
    env = Optimal_Stopping()
    policy = env.binary_policy # policy(theta,s)

if __name__ == '__main__':
    all_REINFORCE_return = []
    all_MVP_return = []
    all_Tamar_return = []
    all_RCPG_return = []
    all_SGD_return = []

    # print "trail#: "

    # p.start(trails_num)
    for i in xrange(trails_num):
        # p.update(i+1)
        REINFORCE_savename = savename = "./" + environment + "_policy/REINFORCE1/_" + str(etar) + "_" + str(episode_num_forpath1) +  "_/REINFORCE_value_" + str(i) + ".txt"
        MVP_savename = "./" + environment + "_policy/MVP/_" + "lbd" + str(lbd) + "_" + str(eta) + "_" + str(episode_num_forpath) + str(IfControl) + "_/MVP_value_" + str(i) + ".txt"
        Tamar_savename = "./" + environment + "_policy/Tamar/_" + str(alpha) + "_" + str(episode_num_forpath2) +  "_/Tamar_value_" + str(i) + ".txt"
        RCPG_savename = "./" + environment + "_policy/RCPG/_" + "lbd" + str(lbd1) + "_" + str(alpharcpg) + "_" + str(episode_num_forpath) + str(IfControl) + "_/RCPG_value_" + str(i) + ".txt"
        SGD_savename = "./" + environment + "_policy/SGD/_" + "lbd" + str(lbd2) + "_" + str(alpharcpg2) + "_" + str(episode_num_forpath) + str(IfControl) + "_/SGD_value_" + str(i) + ".txt"

        REINFORCE_value = np.loadtxt(REINFORCE_savename)
        MVP_value = np.loadtxt(MVP_savename)
        Tamar_value = np.loadtxt(Tamar_savename)
        RCPG_value = np.loadtxt(RCPG_savename)
        SGD_value = np.loadtxt(SGD_savename)

        bd = 14

        if REINFORCE_value >= bd:
            all_REINFORCE_return.append(REINFORCE_value)
        # print "MVP: "
        if MVP_value >= bd:
            all_MVP_return.append(MVP_value)
        # print "Tamar: "
        if Tamar_value >= bd:
            all_Tamar_return.append(Tamar_value)
        if RCPG_value >= bd:
            all_RCPG_return.append(RCPG_value)
        if SGD_value >= bd:
            all_SGD_return.append(SGD_value)
    # p.finish()

    all_REINFORCE_return.sort()
    all_MVP_return.sort()
    all_Tamar_return.sort()
    all_RCPG_return.sort()
    all_SGD_return.sort()

    # print all_REINFORCE_return
    print all_MVP_return

    # print all_Tamar_return

    nb = 0

    all_REINFORCE_return = all_REINFORCE_return[nb:]
    all_MVP_return = all_MVP_return[nb:]
    all_Tamar_return = all_Tamar_return[nb:]
    all_RCPG_return = all_RCPG_return[nb:]
    all_SGD_return = all_SGD_return[nb:]

    print np.std(all_REINFORCE_return)
    print np.std(all_MVP_return)
    print np.std(all_Tamar_return)
    print np.std(all_RCPG_return)
    print np.std(all_SGD_return)


    mv1 = [150]
    mv2 = [165]
    mv3 = [150]
    mv4 = [110]
    mv5 = [135]
    msz = 20
    mew = 2.0

    fig = plt.figure(figsize=(12,9))
    plt.ylim(0,1.3)
    plt.xlim(24.5,31.5)
    sns.distplot(all_MVP_return[:],fit = norm,hist=IfHist,rug=False,kde=False,fit_kws={"color": "#e41a1c", "lw": 5, "label": "fit","linestyle":"-","marker":"o","markevery":mv1,"markersize":msz,"markeredgecolor":"k","markeredgewidth":mew},label = 'MVP')
    sns.distplot(all_SGD_return[:],fit = norm,hist=IfHist,rug=False,kde=False,label = 'SGA',fit_kws={"color": "#999999", "lw": 5, "label": "fit","linestyle":":","marker":"d","markevery":mv2,"markersize":msz,"markeredgecolor":"k","markeredgewidth":mew,"dashes":(1,0.5)})
    sns.distplot(all_RCPG_return[:],fit = norm,hist=IfHist,rug=False,kde=False,label = 'RCPG',fit_kws={"color": "#984ea3", "lw": 5, "label": "fit","linestyle":":","marker":"X","markevery":mv3,"markersize":msz,"markeredgecolor":"k","markeredgewidth":mew})
    sns.distplot(all_Tamar_return[:],fit = norm,hist=IfHist,rug=False,kde=False,label = 'Tamar',fit_kws={"color": "#4daf4a", "lw": 5, "label": "fit","linestyle":"--","marker":">","markevery":mv4,"markersize":msz,"markeredgecolor":"k","markeredgewidth":mew})
    sns.distplot(all_REINFORCE_return[:],fit = norm,hist=IfHist,rug=False,kde=False,label = 'PG',fit_kws={"color": "#377eb8", "lw": 5, "label": "fit","linestyle":"-.","marker":"s","markevery":mv5,"markersize":msz,"markeredgecolor":"k","markeredgewidth":mew})
    leg = plt.legend(loc=[0,0.55],frameon=False,framealpha=1.0,edgecolor='k',ncol=1)
    leg.get_frame().set_linewidth(1.0)
    plt.xlabel(r'Accumulated Reward')
    plt.ylabel('Probability Density Function (PDF)')
    sns.despine()
    fig.tight_layout()
    plt.show()
    fig.savefig("plots/_" + str(eta) + "_" + str(episode_num_forpath) +"_.pdf",bbox_inches='tight')
    print "Succeed!"
