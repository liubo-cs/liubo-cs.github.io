import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA
import seaborn as sns
# import progressbar
# p = progressbar.ProgressBar()

import matplotlib.pyplot as plt

from util import *
from Portfolio import *
from American_Option import *
from Optimal_Stopping import *

np.set_printoptions(precision=3,suppress=True)
#################################################
# Hyperparameters
e = 0.1 # e greedy policy
eta = 0.0001 # learning rate
etay = 0.0001 # learning rate
H = 20000 # Horizon
trails_num = 30
episode_num = 1000

environment = "American_Option" # Portfolio, American_Option

IfHist = True # True, False
#################################################

if environment == "Portfolio":
    env = Portfolio()
    policy = env.binary_policy # policy(theta,s)
if environment == "American_Option":
    env = American_Option()
    policy = env.binary_policy # policy(theta,s)
if environment == "Optimal_Stopping":
    env = Optimal_Stopping()
    policy = env.binary_policy # policy(theta,s)


def choose_action(act_dist):
    action_choices = len(act_dist)
    action = np.random.choice(action_choices,p=act_dist)
    return action

def Portfolio_run_once(theta):

    # REINFORCE_savename = "./Portfolio_policy/REINFORCE/REINFORCE_theta_" + str(i) + ".txt"
    # MVP_savename = "./Portfolio_policy/MVP/MVP_theta_" + str(i) + ".txt"
    # REINFORCE_theta = np.loadtxt(REINFORCE_savename)
    # MVP_theta = np.loadtxt(MVP_savename)

    temp_return = []

    # p.start(episode_num)
    for episode in xrange(episode_num):
        # p.update(episode+1)
        # if episode % 10 == 0:
        # if episode % 10 == 0:
        #     print "episode: ", episode
        s = env.reset()
        IfEnd = False
        total_reward = 0
        grad_logpolicy = theta * 0
        while not IfEnd:
            # feature = env.phi(s)
            act_dist = policy(theta,s)
            a = choose_action(act_dist)
            s, r, IfEnd = env.next_step(s,a)
            total_reward += r
        total_reward += env.ini_money
        total_reward = np.log(total_reward)
        temp_return.append(total_reward)
    # p.finish()
    return np.mean(temp_return)

def American_Option_run_once(theta):

    # REINFORCE_savename = "./Portfolio_policy/REINFORCE/REINFORCE_theta_" + str(i) + ".txt"
    # MVP_savename = "./Portfolio_policy/MVP/MVP_theta_" + str(i) + ".txt"
    # REINFORCE_theta = np.loadtxt(REINFORCE_savename)
    # MVP_theta = np.loadtxt(MVP_savename)

    temp_return = []

    # p.start(episode_num)
    for episode in xrange(episode_num):
        # p.update(episode+1)
        # if episode % 10 == 0:
        # if episode % 10 == 0:
        #     print "episode: ", episode
        s = env.reset()
        IfEnd = False
        total_reward = 0
        grad_logpolicy = theta * 0
        while not IfEnd:
            # feature = env.phi(s)
            act_dist = policy(theta,s)
            a = choose_action(act_dist)
            s, r, IfEnd = env.next_step(s,a)
            total_reward += r
        # total_reward = np.log(total_reward)
        temp_return.append(total_reward)
    # p.finish()
    return np.mean(temp_return)

if environment == "Portfolio":
    run_once = Portfolio_run_once
if environment == "American_Option" or environment == "Optimal_Stopping":
    run_once = American_Option_run_once

if __name__ == '__main__':
    all_REINFORCE_return = []
    all_MVP_return = []
    all_Tamar_return = []

    # print "trail#: "

    # p.start(trails_num)
    for i in xrange(trails_num):
        # p.update(i+1)
        REINFORCE_savename = "./" + environment + "_policy/REINFORCE/REINFORCE_theta_" + str(i) + ".txt"
        MVP_savename = "./" + environment + "_policy/MVP/MVP_theta_" + str(i) + ".txt"
        Tamar_savename = "./" + environment + "_policy/Tamar/Tamar_theta_" + str(i) + ".txt"
        REINFORCE_theta = np.loadtxt(REINFORCE_savename)
        MVP_theta = np.loadtxt(MVP_savename)
        Tamar_theta = np.loadtxt(Tamar_savename)

        print "trail#: ",i
        # print "REINFORCE: "
        all_REINFORCE_return.append(run_once(REINFORCE_theta))
        # print "MVP: "
        all_MVP_return.append(run_once(MVP_theta))
        # print "Tamar: "
        all_Tamar_return.append(run_once(Tamar_theta))
    # p.finish()

    fig = plt.figure(figsize=(12,9))
    sns.distplot(all_REINFORCE_return,color = 'b',hist=IfHist,label = 'REINFORCE')
    sns.distplot(all_MVP_return,color = 'r',hist=IfHist,label = 'MVP')
    sns.distplot(all_Tamar_return,color = 'g',hist=IfHist,label = 'Tamar')
    fig.savefig("temp.pdf")
