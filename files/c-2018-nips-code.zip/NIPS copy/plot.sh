#!/bin/bash
#
#SBATCH --job-name=mvp
#SBATCH --output=outputs/plot.out 
#SBATCH --partition=defq
#SBATCH --mem-per-cpu=1000
python cluster_Prob_Dist_plot.py
