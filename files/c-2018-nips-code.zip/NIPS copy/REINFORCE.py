import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA
import progressbar
p = progressbar.ProgressBar()

import matplotlib.pyplot as plt

from util import *
from Portfolio import *
from American_Option import *
from Optimal_Stopping import *
from cluster_Prob_Dist_Test import *

# import autograd.numpy as np  # Thinly-wrapped numpy
# from autograd import grad    # The only autograd function you may ever need

np.set_printoptions(precision=3,suppress=True)
#################################################
# Hyperparameters
e = 0.1 # e greedy policy
H = 20000 # Horizon
trails_num = 1
episode_num = 40000

IfPrint = True # True, False

environment = "Optimal_Stopping" # Portfolio, American_Option, Optimal_Stopping
#################################################

if environment == "Portfolio":
    env = Portfolio()
    policy = env.binary_policy # policy(theta,s)
    eta = 0.01 # learning rate

if environment == "American_Option":
    env = American_Option()
    policy = env.binary_policy # policy(theta,s)
    eta = 0.02 # learning rate

if environment == "Optimal_Stopping":
    env = Optimal_Stopping()
    policy = env.binary_policy # policy(theta,s)
    eta = 0.001 # learning rate


def choose_action(act_dist):
    action_choices = len(act_dist)
    action = np.random.choice(action_choices,p=act_dist)
    return action


def Portfolio_main(i):
    total_r = []

    s = env.reset()
    feature = env.phi(s)
    theta = feature * 0
    p.start(episode_num)
    for episode in xrange(episode_num):
        p.update(episode+1)
        # if episode % 10 == 0:
        if episode % 10 == 0 and episode > 0 and IfPrint:
            print "episode: ", episode
            print total_reward
        s = env.reset()
        IfEnd = False
        total_reward = 0
        grad_logpolicy = theta * 0
        while not IfEnd:
            # feature = env.phi(s)
            act_dist = policy(theta,s)
            a = choose_action(act_dist)
            s, r, IfEnd = env.next_step(s,a)
            total_reward += r
            grad_logpolicy += env.grad_log_policy(theta,s,a,act_dist)
        total_reward += env.ini_money
        total_reward = np.log(total_reward)
        total_r.append(total_reward)
        # print total_reward
        control = np.mean(total_r)
        theta += eta * (total_reward - control) * grad_logpolicy
    p.finish()
    savename = "./Portfolio_policy/REINFORCE/REINFORCE_theta_" + str(i) + ".txt"
    np.savetxt(savename,theta)
    if IfPrint:
        plt.figure(1)
        plt.plot(total_r,'b-',label = 'REINFORCE')
        plt.show()

def American_Option_main(i):
    total_r = []
    s = env.reset()
    feature = env.phi(s)
    theta = feature * 0
    # p.start(episode_num)
    for episode in xrange(episode_num):
        # p.update(episode+1)
        # if episode % 10 == 0:
        if episode % 10 == 0 and episode > 0 and IfPrint:
            print "episode: ", episode
            print total_reward
        s = env.reset()
        IfEnd = False
        total_reward = 0
        grad_logpolicy = theta * 0
        while not IfEnd:
            # feature = env.phi(s)
            act_dist = policy(theta,s)
            a = choose_action(act_dist)
            s, r, IfEnd = env.next_step(s,a)
            # total_reward += r
            grad_logpolicy += env.grad_log_policy(theta,s,a,act_dist)
            total_reward += r
        total_r.append(total_reward)
        # print total_reward
        control = np.mean(total_r) * 0
        theta += eta * (total_reward - control) * grad_logpolicy
    # p.finish()
    savename = "./" + environment + "_policy/REINFORCE/REINFORCE_theta_" + str(i) + ".txt"
    np.savetxt(savename,theta)
    if IfPrint:
        plt.figure(1)
        plt.plot(total_r,'b-',label = 'REINFORCE')
        plt.show()

    value = American_Option_run_once(theta)

if environment == "Portfolio":
    main = Portfolio_main
if environment == "American_Option" or environment == "Optimal_Stopping":
    main = American_Option_main

if __name__ == '__main__':
    for i in xrange(trails_num):
        print "trail#: ", i
        main(i)
