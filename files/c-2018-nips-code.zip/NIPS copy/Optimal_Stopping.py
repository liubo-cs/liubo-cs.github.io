import itertools
import numpy as np
import sys
import math
import time
from numpy import linalg as LA

from util import *


#################################
# Parameters

T = 20 # length of episode
# N = 4 # length of maturity period
fu = 2
fd = 0.5
x0 = 1.0
p_price = 0.35 # price for down
gamma = 0.95 # discount factor
ph = 0.1
K = 5 # max cost

n = 10 # n order base
#################################


class Optimal_Stopping(object):
    def __init__(self):
        self.timestep = 0
        self.state_space = 2

    def norm(self,s):
        s1 = s.copy()
        s1[0] = np.log(s[0] / x0) / np.log(fu)
        s1[0] /= T
        s1[1] /= T
        return s1

    def reset(self):
        self.timestep = 0
        s = np.zeros(self.state_space)
        s[0] += x0
        s[1] = 0
        return s

    # return reward, state, if_done
    def next_step(self,s,a): # a = 1, stop
        IfEnd = False

        if self.timestep >= T or a == 1:
            IfEnd = True

        # price change
        price_change = np.random.choice(2,p=[p_price, 1 - p_price]) # 0- down, 1 - up
        if price_change == 0:
            s[0] *= fd
        else:
            s[0] *= fu

        reward = 0
        if IfEnd:
            reward -= min(K,s[0])
        else:
            reward -= ph

        reward *= gamma ** self.timestep

        s[1] += 1
        self.timestep += 1

        return s, reward, IfEnd

    def phi(self,s): # Fourier Basis
        s1 = self.norm(s)
        # return s1
        d = s.shape[0]
        y = np.zeros((n + 1) ** d)
        c = np.zeros(d)
        for i in xrange((n + 1) ** d):
            temp = i + 0
            for j in xrange(d):
                c[j] = temp % (n + 1)
                temp -= c[j]
                temp /= (n + 1)
            c_dot_s = np.dot(c,s1)
            y[i] = math.cos(math.pi * c_dot_s)
        return y


    def binary_policy(self,theta,s): # binary policy for Portfolio domain
        # ep = 0.05
        feature = self.phi(s)
        theta_dot_x = np.dot(theta,feature)
        theta_dot_x = max(theta_dot_x,-200)
        # prob = ep + (1 - 2 * ep) / (1 + np.exp(theta_dot_x)) # prob for investing
        prob = 1 / (1 + np.exp(-1 * theta_dot_x)) # prob for investing (a = 1)

        # act_dist = np.zeros(2)
        # act_dist[0] = 1 - prob
        # act_dist[1] = prob
        return [1 - prob, prob]


    def grad_log_policy(self,theta,s,a,act_dist):
        feature = self.phi(s)
        # theta_dot_x = np.dot(theta,feature)
        # if a == 1:
        #     exp_theta_dot_x = np.exp(-1 * theta_dot_x)
        #     grad = feature * exp_theta_dot_x / (1 + exp_theta_dot_x)
        # else:
        #     exp_theta_dot_x = np.exp(theta_dot_x)
        #     grad = -1 * feature * exp_theta_dot_x / (1 + exp_theta_dot_x)

        if a == 1:
            grad = feature * act_dist[0]
        else:
            grad = -1 * feature * act_dist[1]
        return grad
